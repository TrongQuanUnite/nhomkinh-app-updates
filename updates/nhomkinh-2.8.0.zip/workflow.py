"""Workflow schema; stages have distinct values and permissions."""
PLAN=[('ten_cong_trinh','Tên công trình'),('thau','Thầu'),('nguoi_do','Người đo'),('do_dac','Đo đạc'),('lap_lay_ngay','Lắp lấy ngày'),('trang_thai','Trạng thái tổng')]
PRODUCTION=[('sx_cua_nhua','Cửa nhựa'),('sx_cua_so','Cửa sổ'),('sx_cua_di','Cửa đi'),('sx_vom','Vòm'),('sx_kinh_cua','Kính cửa'),('sx_kinh_vom','Kính vòm'),('sx_khung_bao_ve','Khung bảo vệ'),('sx_lan_can','Lan can'),('sx_cau_thang','Cầu thang'),('sx_bep','Bếp')]
INSTALLATION=[('ld_cua_nhua','Cửa nhựa'),('ld_cua','Cửa'),('ld_khung_bao_ve','Khung bảo vệ'),('ld_lan_can','Lan can'),('ld_cau_thang','Cầu thang'),('ld_bep','Bếp'),('ve_sinh','Vệ sinh'),('giao_chia_khoa','Giao chìa khóa')]
WORKFLOW=PLAN+PRODUCTION+INSTALLATION+[('dinh_vi','Định vị')]
NOTE_FIELDS=[k+'_ghi_chu' for k,_ in WORKFLOW]

OVERALL_STATUSES=["Đang Thực Hiện","Hoàn Thành"]
def overall_status(value,strict=False):
    text=str(value).strip().casefold()
    if text=="hoàn thành":return OVERALL_STATUSES[1]
    if strict and text not in {"","đang thực hiện"}:raise ValueError("Trạng thái không hợp lệ")
    return OVERALL_STATUSES[0]
