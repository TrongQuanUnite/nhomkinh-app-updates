from urllib.parse import urlparse
def normalize_link(value):
    value=str(value or '').strip()
    if not value:return ''
    parsed=urlparse(value)
    if parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password or len(value)>3000 or any(ord(c)<32 for c in value):
        raise ValueError('Link bản vẽ cần là đường dẫn HTTPS hợp lệ.')
    return value

def drive_file_id(value):
    import re
    from urllib.parse import parse_qs
    parsed=urlparse(value)
    if parsed.hostname!='drive.google.com':return ''
    match=re.search(r'^/file/d/([A-Za-z0-9_-]+)(?:/|$)',parsed.path)
    if match:return match.group(1)
    raw=parse_qs(parsed.query).get('id',[''])[0]
    return raw if re.fullmatch('[A-Za-z0-9_-]+',raw) else ''
