import datetime, hashlib, hmac, json, secrets, re, time
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException, Request, UploadFile, File, Form
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse, RedirectResponse, Response
from pydantic import BaseModel, ConfigDict
import jwt
import reports
from permissions import editable_fields,can_upload,PERMISSION_FIELDS,tab_permissions
from store import BASE, FIELDS, LABELS, LOCK, store, config, save_json, norm
app=FastAPI(title='Nhật ký Nhôm Kính')
secret_path=BASE/'.session_secret'
if not secret_path.exists():secret_path.write_text(secrets.token_hex(32))
SECRET=secret_path.read_text()
def hash_password(password,salt=None):
    salt=salt or secrets.token_hex(16)
    return salt+':'+hashlib.pbkdf2_hmac('sha256',password.encode(),salt.encode(),260000).hex()
def check_password(password,stored):return hmac.compare_digest(hash_password(password,stored.split(':')[0]),stored)
def users():return json.loads((BASE/'users.json').read_text('utf8')) if (BASE/'users.json').exists() else {}
def public(u):
    data={k:v for k,v in u.items() if k not in {'password_hash','revision'}}
    data['permissions']=sorted(tab_permissions(u));data['status']=u.get('status','active')
    return data
def user(request:Request):
    try:
        payload=jwt.decode(request.cookies.get('session',''),SECRET,algorithms=['HS256']);u=users().get(payload['sub'])
        if not u or u.get('status','active')!='active' or payload.get('revision')!=u.get('revision'):raise ValueError()
        return u
    except Exception:raise HTTPException(401,'Vui lòng đăng nhập lại.')
def reader(request:Request):
    try:return user(request)
    except HTTPException as exc:
        if exc.status_code!=401:raise
        return {'username':'','full_name':'Khách','role':'guest','permissions':[],'status':'active'}
def owner(u=Depends(user)):
    if u['role']!='chu':raise HTTPException(403,'Chỉ chủ xưởng được dùng chức năng này.')
    return u
def target(row,u,expected=None):
    p=next((p for p in store.rows() if p['row_index']==row),None)
    if not p:raise HTTPException(404,'Không tìm thấy công trình.')
    if expected and expected!=p['version']:raise HTTPException(409,'Dữ liệu đã thay đổi. Bấm Làm mới rồi cập nhật lại để tránh ghi đè.')
    return p
@app.middleware('http')
async def protection(request,call_next):
    if request.method in ['POST','PUT','DELETE']:
        origin=request.headers.get('origin')
        if origin and origin!=str(request.base_url).rstrip('/'):
            return JSONResponse({'detail':'Nguồn yêu cầu không hợp lệ.'},403)
        if request.headers.get('x-app-request')!='1':return JSONResponse({'detail':'Yêu cầu không hợp lệ.'},403)
    response=await call_next(request);response.headers['X-Content-Type-Options']='nosniff';response.headers['Cache-Control']='no-store';return response
@app.exception_handler(Exception)
async def error(request,exc):
    msg=str(exc) if isinstance(exc,ValueError) else 'Không kết nối được Google. Kiểm tra mạng, quyền chia sẻ, tên trang tính và cấu hình. Nếu tải ảnh, kiểm tra quyền thư mục và dung lượng Drive.'
    return JSONResponse({'detail':msg},503)
@app.get('/',response_class=HTMLResponse)
def home():return (BASE/'templates/index.html').read_text('utf8')
@app.get('/privacy',response_class=HTMLResponse)
def privacy():return (BASE/'templates/privacy.html').read_text('utf8')
@app.get('/sw.js')
def service_worker():
    return Response((BASE/'templates/sw.js').read_text('utf8'),media_type='application/javascript',headers={'Service-Worker-Allowed':'/'})
@app.get('/manifest.json')
def web_manifest():
    return JSONResponse({'name':'Nhôm Kính Trí Thành','short_name':'Trí Thành','description':'Quản lý tiến độ xưởng, lắp đặt và nhắc lịch công trình Nhôm Kính Trí Thành','start_url':'/','scope':'/','display':'standalone','background_color':'#f4f7f9','theme_color':'#123848','icons':[{'src':'/icon.svg','sizes':'any','type':'image/svg+xml','purpose':'any maskable'}]})
@app.get('/icon.svg')
def app_icon():
    svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><rect width="128" height="128" rx="28" fill="#123848"/><rect x="14" y="14" width="100" height="100" rx="20" fill="none" stroke="#3ab1a0" stroke-width="6"/><text x="64" y="79" text-anchor="middle" font-family="system-ui,sans-serif" font-weight="800" font-size="46" fill="#ffffff">TT</text></svg>'
    return Response(svg,media_type='image/svg+xml')
@app.get('/api/status')
def status():return {'setup_required':not users(),'mode':config()['mode']}
class Initial(BaseModel):password:str
@app.post('/api/setup')
def setup(body:Initial,request:Request):
    if request.client.host not in ['127.0.0.1','::1','testclient']:raise HTTPException(403,'Tạo tài khoản lần đầu trên máy chạy app: localhost:8000.')
    with LOCK:
        if users():raise HTTPException(409,'Đã tạo tài khoản chủ.')
        if len(body.password)<8:raise HTTPException(400,'Mật khẩu cần ít nhất 8 ký tự.')
        save_json(BASE/'users.json',{'trithanh':{'username':'trithanh','full_name':'Chủ xưởng','role':'chu','doi_truong':'','password_hash':hash_password(body.password),'revision':secrets.token_hex(8)}})
    return {'ok':True}
class Login(BaseModel):username:str;password:str;remember_me:bool=True
attempts={}
@app.post('/api/login')
def login(body:Login,request:Request):
    key=request.client.host;now=time.time();recent=[t for t in attempts.get(key,[]) if now-t<300];attempts[key]=recent
    if len(recent)>=10:raise HTTPException(429,'Thử lại sau 5 phút.')
    u=users().get(body.username.strip().lower())
    if not u or not check_password(body.password,u['password_hash']):recent.append(now);raise HTTPException(401,'Sai tài khoản hoặc mật khẩu.')
    if u.get('status','active')!='active':raise HTTPException(403,'Tài khoản đang chờ chủ duyệt hoặc đã tạm khóa.')
    attempts.pop(key,None);seconds=90*86400 if body.remember_me else 86400
    token=jwt.encode({'sub':u['username'],'revision':u['revision'],'exp':int(now)+seconds},SECRET,algorithm='HS256')
    res=JSONResponse(public(u));res.set_cookie('session',token,max_age=seconds if body.remember_me else None,httponly=True,samesite='strict',secure=request.url.scheme=='https');return res
class Registration(BaseModel):
    model_config=ConfigDict(extra='forbid')
    username:str
    full_name:str
    password:str
    doi_truong:str=''
registration_attempts={}
@app.post('/api/register')
def register(body:Registration,request:Request):
    name=body.username.strip().lower();full_name=body.full_name.strip();now=time.time();ip=request.client.host
    if not re.fullmatch('[a-z0-9_]{2,30}',name) or name in {'chu','trithanh'} or not 1<=len(full_name)<=100 or not 8<=len(body.password)<=200 or len(body.doi_truong)>100:raise HTTPException(400,'Tên đăng nhập 2–30 ký tự a-z/0-9/_. Nhập họ tên và mật khẩu 8–200 ký tự.')
    with LOCK:
        if not users():raise HTTPException(403,'Chủ cần thiết lập app trước khi thợ đăng ký.')
        recent=[t for t in registration_attempts.get(ip,[]) if now-t<600]
        if len(recent)>=5:raise HTTPException(429,'Đã đăng ký nhiều lần. Thử lại sau 10 phút.')
        db=users()
        if name in db:raise HTTPException(409,'Tên đăng nhập đã có người dùng.')
        recent.append(now);registration_attempts[ip]=recent
        db[name]={'username':name,'full_name':full_name,'doi_truong':body.doi_truong.strip(),'role':'tho','status':'pending','permissions':[],
                  'password_hash':hash_password(body.password),'revision':secrets.token_hex(8)}
        save_json(BASE/'users.json',db)
    return {'ok':True,'message':'Đăng ký thành công. Chờ chủ duyệt tài khoản và cấp quyền trước khi đăng nhập.'}
@app.post('/api/logout')
def logout():
    res=JSONResponse({'ok':True});res.delete_cookie('session');return res
@app.get('/api/me')
def me(u=Depends(reader)):return public(u)
@app.get('/api/projects')
def projects(u=Depends(reader)):
    import webpush
    with LOCK:
        rows=store.rows()
        from drawings import stored_files
        for p in rows:p['archive_files']=stored_files(p)
        webpush.trigger_check_async(rows)
        return rows
class Change(BaseModel):
    model_config=ConfigDict(extra='forbid')
    version:str
    data:dict[str,str]
@app.put('/api/projects/{row}')
def update(row:int,body:Change,u=Depends(user)):
    with LOCK:
        p=target(row,u,body.version)
        allowed=editable_fields(u)|({'thoi_gian'} if u['role']=='chu' else set())
        if not set(body.data)<=allowed:raise HTTPException(403,'Không được sửa trường này.')
        if any(len(v)>15000 for v in body.data.values()):raise HTTPException(400,'Nội dung quá dài.')
        data=body.data.copy()
        from workflow import validate_glass
        try:validate_glass(data,p)
        except ValueError as e:raise HTTPException(400,str(e))
        if 'trang_thai' in data:
            from workflow import overall_status
            try:data['trang_thai']=overall_status(data['trang_thai'],strict=True)
            except ValueError:raise HTTPException(400,'Trạng thái tổng chỉ có Đang Thực Hiện / Hoàn Thành.')
        if 'ten_cong_trinh' in data and not data['ten_cong_trinh'].strip():raise HTTPException(400,'Tên công trình không được trống.')
        if 'ban_ve' in data:
            from drawings import normalize_link
            try:data['ban_ve']=normalize_link(data['ban_ve'])
            except ValueError as e:raise HTTPException(400,str(e))
        if data.get('dinh_vi'):
            from location_scanner import normalize_map_url
            data['dinh_vi']=normalize_map_url(data['dinh_vi'])
            if not data['dinh_vi']:raise HTTPException(400,'Định vị phải là link Google Maps hợp lệ.')
        note=data.pop('tien_do_bao_cao','').strip()
        notes=[]
        for k,v in data.items():
            if k.endswith('_ghi_chu') and v!=p.get(k,''):
                notes.append(LABELS[FIELDS.index(k[:-8])]+': '+(v.strip() or '(Đã xóa ghi chú hiện tại)'))
        text='\n'.join([x for x in [note,*notes] if x])
        uid=reports.project_id(p,data) if text else None
        if text:
            stamp=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=7))).strftime('%d/%m/%Y %H:%M')
            data['tien_do_bao_cao']=(p['tien_do_bao_cao']+'\n['+stamp+' · '+u['full_name']+'] '+text).strip()[-45000:]
        store.update(row,data)
        if text:reports.append(uid,p,u,text)
        if 'lap_lay_ngay' in data or 'trang_thai' in data:
            import webpush
            webpush.invalidate_cache()
            webpush.trigger_check_async()
    return {'ok':True}
@app.post('/api/projects')
def create(data:dict[str,str],u=Depends(owner)):
    if not set(data)<=set(FIELDS)-{'hinh_anh','cong_trinh_id'} or not data.get('ten_cong_trinh','').strip():raise HTTPException(400,'Kiểm tra tên và thông tin công trình.')
    from workflow import overall_status,validate_glass
    try:validate_glass(data)
    except ValueError as e:raise HTTPException(400,str(e))
    try:data['trang_thai']=overall_status(data.get('trang_thai',''),strict=True)
    except ValueError:raise HTTPException(400,'Trạng thái tổng chỉ có Đang Thực Hiện / Hoàn Thành.')
    with LOCK:
        if 'ban_ve' in data:
            from drawings import normalize_link
            try:data['ban_ve']=normalize_link(data['ban_ve'])
            except ValueError as e:raise HTTPException(400,str(e))
        data['cong_trinh_id']=secrets.token_hex(16)
        notes=[LABELS[FIELDS.index(k[:-8])]+': '+v for k,v in data.items() if k.endswith('_ghi_chu') and v.strip()]
        store.create(data)
        if notes:reports.append(data['cong_trinh_id'],{},u,'\n'.join(notes))
        import webpush
        webpush.invalidate_cache()
        if data.get('lap_lay_ngay'):webpush.trigger_check_async()
    return {'ok':True}
class DeleteProject(BaseModel):
    model_config=ConfigDict(extra='forbid')
    version:str
@app.delete('/api/projects/{row}')
def delete_project(row:int,body:DeleteProject,u=Depends(owner)):
    if not body.version:raise HTTPException(400,'Làm mới công trình trước khi xóa.')
    with LOCK:
        target(row,u,body.version);store.delete(row)
        import webpush
        webpush.invalidate_cache()
    return {'ok':True}

MEDIA_TYPES={'image/jpeg','image/png','image/webp','image/heic','image/heif','video/mp4','video/quicktime','video/webm','video/3gpp'}
def check_media(file):
    if file.content_type not in MEDIA_TYPES:raise HTTPException(400,'Chỉ nhận ảnh hoặc video thông dụng.')
    file.file.seek(0,2);size=file.file.tell();file.file.seek(0)
    if size==0 or size>100*1024*1024:raise HTTPException(400,'File phải từ 1 byte đến 100 MB.')
@app.get('/api/projects/{row}/reports')
def get_reports(row:int,u=Depends(reader)):
    with LOCK:
        p=target(row,u);entries=reports.list_reports(p)
        return {'entries':entries,'legacy':p.get('tien_do_bao_cao','') if not entries else '', 'legacy_media':p.get('hinh_anh','')}
@app.post('/api/projects/{row}/reports')
def add_report(row:int,version:str=Form(...),note:str=Form(''),files:list[UploadFile]=File(default=[]),u=Depends(user)):
    with LOCK:
        p=target(row,u,version);note=note.strip()
        if note and 'tien_do_bao_cao' not in editable_fields(u):raise HTTPException(403,'Chưa được cấp quyền viết báo cáo.')
        if files and not can_upload(u):raise HTTPException(403,'Chưa được cấp quyền tải ảnh / clip.')
        if not note and not files:raise HTTPException(400,'Nhập báo cáo hoặc chọn ảnh / clip.')
        if len(note)>15000 or len(files)>10:raise HTTPException(400,'Báo cáo tối đa 15.000 ký tự và 10 file mỗi lần.')
        for file in files:check_media(file)
        data={};uid=reports.project_id(p,data)
        # Prepare only headers before uploading, never rearrange existing data.
        if files and config()['mode']=='google':store.prepare_columns()
        attachments=[];partial=''
        for file in files:
            try:
                link=store.upload(file.file,file.filename or 'media',file.content_type,p['ten_cong_trinh'])
                attachments.append({'url':link,'name':Path(file.filename or 'media').name,'mime':file.content_type})
            except Exception:
                if not attachments:raise
                partial='Một số file chưa tải được; các file đã tải và báo cáo đã được lưu. Chọn lại những file còn thiếu.';break
        if attachments:data['hinh_anh']=(p['hinh_anh']+'\n'+'\n'.join(a['url'] for a in attachments)).strip()
        text=note or 'Đã gửi ảnh / clip.'
        stamp=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=7))).strftime('%d/%m/%Y %H:%M')
        data['tien_do_bao_cao']=(p['tien_do_bao_cao']+'\n['+stamp+' · '+u['full_name']+'] '+text).strip()[-45000:]
        try:store.update(row,data)
        except Exception:
            if attachments:raise HTTPException(503,'Đã tải Drive nhưng chưa lưu báo cáo. Giữ các link: '+' '.join(a['url'] for a in attachments))
            raise
        entry=reports.append(uid,p,u,text,attachments)
    return {'ok':True,'entry':entry,'message':partial or 'Đã lưu báo cáo và file đính kèm.'}
@app.post('/api/projects/{row}/media')
def media(row:int,version:str=Form(...),file:UploadFile=File(...),u=Depends(user)):
    return add_report(row,version,'',[file],u)
@app.get('/api/projects/{row}/drawing')
def view_drawing(row:int,download:bool=False,u=Depends(reader)):
    with LOCK:
        p=target(row,u);link=p.get('ban_ve','')
    if not link:raise HTTPException(404,'Công trình chưa có bản vẽ.')
    from drawings import normalize_link,drive_file_id
    link=normalize_link(link);file_id=drive_file_id(link)
    if not file_id:return RedirectResponse(link,status_code=307)
    output=store.download_pdf(file_id)
    def chunks():
        try:
            while True:
                data=output.read(1024*1024)
                if not data:break
                yield data
        finally:output.close()
    return StreamingResponse(chunks(),media_type='application/pdf',headers={'Content-Disposition':('attachment' if download else 'inline')+'; filename="ban-ve.pdf"'})

@app.post('/api/projects/{row}/drawing')
def upload_drawing(row:int,version:str=Form(...),file:UploadFile=File(...),u=Depends(user)):
    with LOCK:
        p=target(row,u,version)
        if 'ban_ve' not in editable_fields(u):raise HTTPException(403,'Chưa được cấp quyền tab Bản vẽ.')
        file.file.seek(0,2);size=file.file.tell();file.file.seek(0)
        if size==0 or size>100*1024*1024:raise HTTPException(400,'PDF phải từ 1 byte đến 100 MB.')
        if file.file.read(5)!=b'%PDF-':raise HTTPException(400,'Chỉ nhận file PDF thật.')
        file.file.seek(0)
        if config()['mode']=='google':store.prepare_columns()
        link=store.upload(file.file,file.filename or 'ban-ve.pdf','application/pdf',p['ten_cong_trinh'])
        from drawings import normalize_link
        link=normalize_link(link)
        try:store.update(row,{'ban_ve':link})
        except Exception:raise HTTPException(503,'Đã tải PDF nhưng chưa lưu được công trình. Giữ link: '+link)
    return {'ok':True,'url':link}

@app.post('/api/projects/{row}/files')
def upload_project_file(row:int,version:str=Form(...),file:UploadFile=File(...),u=Depends(user)):
    from drawings import stored_files,save_files
    with LOCK:
        p=target(row,u,version)
        if 'ban_ve' not in editable_fields(u):raise HTTPException(403,'Chưa được cấp quyền tab Bản vẽ.')
        entries=stored_files(p)
        name=(file.filename or 'file').replace('\\','/').split('/')[-1]
        name=''.join(c for c in name if ord(c)>=32 and ord(c)!=127).strip()[:200] or 'file'
        file.file.seek(0,2);size=file.file.tell();file.file.seek(0)
        if not 0<size<=100*1024*1024:raise HTTPException(400,'File phải từ 1 byte đến 100 MB.')
        entry={'id':secrets.token_hex(12),'url':'https://drive.google.com/file/d/'+'x'*100+'/view','name':name,'size':size,'author':u['full_name'],'time':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=7))).isoformat(timespec='seconds')}
        if config()['mode']=='google':store.prepare_columns()
        data={};uid=reports.project_id(p,data)
        store.update(row,data)
        link=store.upload(file.file,name,'application/octet-stream',p['ten_cong_trinh'])
        entry['url']=link;entries.append(entry)
        try:save_files(uid,entries)
        except Exception:raise HTTPException(503,'Đã tải file nhưng chưa lưu được công trình. Giữ link: '+link)
    return {'ok':True,'entry':entry}

@app.delete('/api/projects/{row}/files/{file_key}')
def remove_project_file(row:int,file_key:str,body:Change,u=Depends(user)):
    from drawings import stored_files,save_files
    with LOCK:
        p=target(row,u,body.version)
        if 'ban_ve' not in editable_fields(u):raise HTTPException(403,'Chưa được cấp quyền tab Bản vẽ.')
        if file_key=='legacy-pdf':
            store.update(row,{'ban_ve':''})
        else:
            entries=stored_files(p)
            if not any(f['id']==file_key for f in entries):raise HTTPException(404,'Không tìm thấy file.')
            data={};uid=reports.project_id(p,data);store.update(row,data)
            save_files(uid,[f for f in entries if f['id']!=file_key])
    return {'ok':True}

@app.get('/api/projects/{row}/files/{file_key}')
def download_project_file(row:int,file_key:str,preview:bool=False,u=Depends(reader)):
    from drawings import stored_files,drive_file_id
    from urllib.parse import quote
    with LOCK:
        p=target(row,u)
        entry=next((f for f in stored_files(p) if f['id']==file_key),None)
        if not entry:raise HTTPException(404,'Không tìm thấy file trong công trình.')
    pdf=preview and entry['name'].lower().endswith('.pdf')
    output=store.download_file(drive_file_id(entry['url']),pdf=pdf)
    def chunks():
        try:
            while True:
                data=output.read(1024*1024)
                if not data:break
                yield data
        finally:output.close()
    return StreamingResponse(chunks(),media_type='application/pdf' if pdf else 'application/octet-stream',headers={'Content-Disposition':('inline' if pdf else 'attachment')+"; filename=download; filename*=UTF-8''"+quote(entry['name'],safe=''),'X-Content-Type-Options':'nosniff'})

@app.get('/api/config')
def get_config(u=Depends(owner)):return config()
@app.put('/api/config')
def put_config(data:dict[str,str],u=Depends(owner)):
    if set(data)!={'mode','spreadsheet_id','worksheet','drive_folder_id'} or data['mode'] not in ['demo','google']:raise HTTPException(400,'Cấu hình không hợp lệ.')
    for key in ['spreadsheet_id','drive_folder_id']:
        value=data[key];match=re.search(r'/(?:d|folders)/([a-zA-Z0-9_-]+)',value);data[key]=match.group(1) if match else value.strip()
    with LOCK:save_json(BASE/'config.json',data)
    return {'ok':True}
@app.post('/api/check-google')
def check(u=Depends(owner)):
    ws,_=store.connect();cols=store.columns(ws.row_values(1));missing=[LABELS[FIELDS.index(k)] for k in FIELDS if k not in cols];return {'ok':True,'message':'Đọc được Sheet. '+('Thiếu cột: '+', '.join(missing)+'. Bấm Bổ sung cột.' if missing else 'Đã đủ cột quản lý/Zalo.')+' Chưa kiểm tra tải ảnh.'}
@app.get('/api/users')
def list_users(u=Depends(owner)):return [public(x) for x in users().values()]
class Account(BaseModel):
    model_config=ConfigDict(extra='forbid')
    username:str
    full_name:str
    doi_truong:str=''
    password:str=''
    permissions:list[str]=[]
    status:str='active'
@app.post('/api/users')
def add_user(data:Account,u=Depends(owner)):
    name=data.username.strip().lower();password=data.password
    if not re.fullmatch('[a-z0-9_]{2,30}',name) or name in {'chu','trithanh'} or not data.full_name.strip():raise HTTPException(400,'Tên tài khoản 2–30 ký tự a-z/0-9/_. Nhập tên hiển thị.')
    if data.status not in {'active','pending','disabled'}:raise HTTPException(400,'Trạng thái tài khoản không hợp lệ.')
    if not set(data.permissions)<=PERMISSION_FIELDS:raise HTTPException(400,'Danh sách quyền không hợp lệ.')
    with LOCK:
        db=users();old=db.get(name)
        if old and old['role']=='chu':raise HTTPException(403,'Không được thay tài khoản chủ bằng tài khoản thợ.')
        if (not old or password) and len(password)<8:raise HTTPException(400,'Tài khoản mới cần mật khẩu ít nhất 8 ký tự. Khi sửa, để trống để giữ mật khẩu.')
        db[name]={'username':name,'full_name':data.full_name.strip(),'doi_truong':data.doi_truong.strip(),'role':'tho','status':data.status,'permissions':sorted(set(data.permissions)),
                  'password_hash':hash_password(password) if password else old['password_hash'],
                  'revision':secrets.token_hex(8) if password or not old else old['revision']}
        save_json(BASE/'users.json',db)
    return {'ok':True}

# Update settings are separate from Google config and are always preserved.
import updater, threading
update_lock=threading.Lock()
def local_owner(request:Request,u=Depends(owner)):
    if request.client.host not in ['127.0.0.1','::1','testclient']:raise HTTPException(403,'Cập nhật app trên máy chủ tại localhost:8000.')
    return u
@app.get('/api/update/status')
def update_status(u=Depends(owner)):
    p=BASE/'.updates/result.json'
    return {'current':updater.VERSION,'settings':updater.settings(),'result':json.loads(p.read_text('utf8')) if p.exists() else None}
@app.put('/api/update/settings')
def update_settings(data:dict[str,str],u=Depends(local_owner)):
    updater.set_repository(data.get('repository',''));return {'ok':True}
@app.post('/api/update/check')
def check_update(u=Depends(owner)):return updater.check()
@app.post('/api/update/install')
def install_update(u=Depends(local_owner)):
    callback=getattr(app.state,'restart_callback',None)
    if callback is None:raise HTTPException(400,'Chạy app bằng CHAY_UNG_DUNG.bat để tự khởi động lại khi cập nhật.')
    if not update_lock.acquire(blocking=False):raise HTTPException(409,'Đang chuẩn bị cập nhật, vui lòng chờ.')
    try:
        if (BASE/'.updates/pending.json').exists():
            job=json.loads((BASE/'.updates/pending.json').read_text('utf8'))
            timer=threading.Timer(2,callback);timer.daemon=True;timer.start()
            return {'ok':True,'job_id':job['job_id'],'message':'Gói đã tải xong. Đang tiếp tục khởi động lại để cài cập nhật.'}
        info=updater.check()
        if not info['available']:raise HTTPException(400,'Không có bản mới.')
        job_id=updater.stage(info['release'])
        timer=threading.Timer(2,callback);timer.daemon=True;timer.start()
        return {'ok':True,'job_id':job_id,'message':'Đã tải bản mới. App đang khởi động lại, giữ cửa sổ chạy mở.'}
    finally:update_lock.release()

import preferences
@app.get('/api/options')
def get_options(u=Depends(reader)):return preferences.get_options()
@app.put('/api/options')
def put_options(data:dict[str,list[str]],u=Depends(owner)):
    with LOCK:preferences.put_options(data)
    return {'ok':True}

import zalo_integration as zalo
@app.get('/api/zalo/settings')
def zalo_settings(u=Depends(owner)):return zalo.settings()
@app.put('/api/zalo/settings')
def save_zalo_settings(data:dict,u=Depends(local_owner)):
    if set(data)!=set(zalo.DEFAULT) or not isinstance(data['senders'],dict) or not isinstance(data['enabled'],bool) or not isinstance(data['auto_apply'],bool):raise HTTPException(400,'Cấu hình Zalo không hợp lệ.')
    if not isinstance(data['location_enabled'],bool) or not isinstance(data['reminders_enabled'],bool) or not isinstance(data['location_group_name'],str) or not isinstance(data['reminder_recipient'],str) or len(data['location_group_name'])>200 or len(data['reminder_recipient'])>200:raise HTTPException(400,'Cấu hình định vị/nhắc lịch không hợp lệ.')
    if data['location_enabled'] and not data['location_group_name'].strip():raise HTTPException(400,'Nhập tên nhóm định vị.')
    if not isinstance(data['mention'],str) or not re.fullmatch(r'[\w -]{1,40}',data['mention']) or not isinstance(data['group_name'],str) or len(data['group_name'])>200:raise HTTPException(400,'Kiểm tra tên nhóm và tên gọi bot.')
    if data['enabled']:raise HTTPException(403,'Zalo đang tạm dừng trong bản web này.')
    if data['enabled'] and not data['group_name'].strip():raise HTTPException(400,'Nhập tên nhóm công việc.')
    db=users()
    if any(not isinstance(k,str) or not k.strip() or v not in db for k,v in data['senders'].items()):raise HTTPException(400,'Tên Zalo cần ghép với tài khoản web có sẵn.')
    with LOCK:save_json(BASE/'zalo_settings.json',data)
    if data['enabled'] and 'bot_manager' in globals():bot_manager.resume()
    return {'ok':True}
@app.get('/api/zalo/events')
def zalo_events(u=Depends(owner)):return list(reversed(zalo.queue()))[:100]
@app.post('/api/zalo/events/{event_id}/approve')
def approve_zalo(event_id:str,data:dict,u=Depends(owner)):
    with LOCK:
        events=zalo.queue();event=next((e for e in events if e['id']==event_id),None)
        if not event or event['status']!='pending':raise HTTPException(409,'Báo cáo không còn chờ duyệt.')
        reply=zalo.apply(event,int(data.get('project_id',0)),u);zalo.save_events(events)
    return {'ok':True,'message':reply}
@app.post('/api/zalo/events/{event_id}/reject')
def reject_zalo(event_id:str,u=Depends(owner)):
    with LOCK:
        events=zalo.queue();event=next((e for e in events if e['id']==event_id),None)
        if not event or event['status']!='pending':raise HTTPException(409,'Báo cáo không còn chờ duyệt.')
        event['status']='rejected';zalo.save_events(events)
    return {'ok':True}
@app.post('/api/zalo/bridge')
def zalo_bridge(data:dict,request:Request):
    auth=request.headers.get('Authorization','')
    if request.client.host not in ['127.0.0.1','::1','testclient'] or not hmac.compare_digest(auth,'Bearer '+zalo.token()):raise HTTPException(403,'Bridge chưa được xác thực.')
    return zalo.receive(data)

import zalo_ai
@app.get('/api/zalo/ai')
def get_zalo_ai(u=Depends(owner)):return zalo_ai.public_config()
@app.put('/api/zalo/ai')
def put_zalo_ai(data:dict,u=Depends(local_owner)):
    with LOCK:zalo_ai.save_config(data)
    return {'ok':True}


import webpush
@app.get('/api/push/key')
def get_push_key(u=Depends(user)):
    subs=webpush.active_subscriptions()
    return {'public_key':webpush.public_key(),'subscribed_count':len(subs)}
@app.post('/api/push/subscribe')
def push_subscribe(data:dict,request:Request,u=Depends(user)):
    try:entry=webpush.subscribe(u,data,request.headers.get('user-agent',''))
    except ValueError as e:raise HTTPException(400,str(e))
    webpush.trigger_check_async()
    return {'ok':True,'endpoint':entry['endpoint'],'message':'Đã bật thông báo đẩy nhắc lịch trước 24 giờ trên thiết bị này.'}
@app.post('/api/push/unsubscribe')
def push_unsubscribe(data:dict,u=Depends(user)):
    webpush.unsubscribe(data.get('endpoint',''))
    return {'ok':True,'message':'Đã tắt thông báo đẩy trên thiết bị này.'}
@app.post('/api/push/test')
def push_test(data:dict,u=Depends(user)):
    endpoint=str(data.get('endpoint') or '').strip()
    subs=webpush.active_subscriptions()
    targets=[s for s in subs if s.get('endpoint')==endpoint] if endpoint else [s for s in subs if s.get('username')==u['username']]
    if not targets and data.get('subscription'):
        try:targets=[webpush.subscribe(u,data['subscription'])]
        except ValueError as e:raise HTTPException(400,str(e))
    if not targets:raise HTTPException(400,'Thiết bị này chưa bật thông báo. Hãy bấm Bật thông báo trước.')
    payload={'title':'🔔 Nhôm Kính Trí Thành — Nhắc lịch hoạt động!','body':'Thiết bị sẽ tự động đổ chuông & hiện thông báo trước giờ Lắp lấy ngày 24 tiếng, kể cả khi đóng web.','tag':'nhomkinh-test-'+secrets.token_hex(4),'url':'/'}
    sent=0
    for s in targets:
        try:
            ok,_=webpush.send_push(s,payload)
            if ok:sent+=1
        except Exception:continue
    if not sent:raise HTTPException(503,'Không gửi được thông báo tới trình duyệt. Hãy thử Tắt rồi Bật lại thông báo trên thiết bị này.')
    return {'ok':True,'message':'Đã gửi thông báo thử! Kiểm tra thông báo vừa hiện trên điện thoại / máy tính của bạn.'}

# Lifecycle also applies when launched by uvicorn directly.
from bot_manager import manager as bot_manager
@app.on_event('startup')
def start_integrated_bot():
    import owner_setup
    owner_setup.apply()
    # Zalo is paused while the web workflow is completed. Retain all settings.
    with LOCK:
        cfg=zalo.settings();cfg['enabled']=False;save_json(BASE/'zalo_settings.json',cfg)
    webpush.start_worker()
@app.on_event('shutdown')
def stop_integrated_bot():bot_manager.close()
@app.get('/api/zalo/runtime')
def zalo_runtime(u=Depends(owner)):return bot_manager.snapshot()
@app.post('/api/zalo/start')
def start_zalo(u=Depends(local_owner)):
    raise HTTPException(403,'Zalo đang tạm dừng trong bản web này.')
@app.post('/api/zalo/stop')
def stop_zalo(u=Depends(local_owner)):
    cfg=zalo.settings();cfg['enabled']=False
    with LOCK:save_json(BASE/'zalo_settings.json',cfg)
    bot_manager.pause();return {'ok':True}

@app.post('/api/prepare-columns')
def prepare_columns(u=Depends(owner)):
    with LOCK:added=store.prepare_columns()
    return {'ok':True,'message':'Đã thêm cột: '+', '.join(added) if added else 'Không cần thêm cột. Các cột hiện có được giữ nguyên.'}

def require_bridge(request):
    if request.client.host not in ['127.0.0.1','::1','testclient'] or not hmac.compare_digest(request.headers.get('Authorization',''),'Bearer '+zalo.token()):raise HTTPException(403,'Bridge chưa được xác thực.')
@app.post('/api/zalo/location')
def bridge_location(data:dict,request:Request):
    require_bridge(request);return zalo.receive_location(data)
@app.post('/api/zalo/reminders')
def bridge_reminders(request:Request):
    require_bridge(request)
    import zalo_reminders
    return zalo_reminders.due()
@app.post('/api/zalo/reminders/{key}/sent')
def bridge_reminder_sent(key:str,request:Request):
    require_bridge(request)
    import zalo_reminders
    zalo_reminders.acknowledge(key);return {'ok':True}
@app.post('/api/zalo/import-config')
def import_old_zalo(file:UploadFile=File(...),u=Depends(local_owner)):
    data=file.file.read(65537)
    if len(data)>65536:raise HTTPException(400,'File cấu hình tối đa 64 KB.')
    values={}
    for line in data.decode('utf-8-sig').splitlines():
        line=line.strip()
        if not line or line.startswith('#') or '=' not in line:continue
        k,v=line.split('=',1);values[k.strip()]=v.strip().strip('"').strip("'")
    with LOCK:
        cfg=zalo.settings()
        for old,new in [('MAIN_GROUP_NAME','group_name'),('LOCATION_GROUP_NAME','location_group_name'),('REMINDER_MENTION_NAME','reminder_recipient')]:
            if values.get(old):cfg[new]=values[old]
        cfg['enabled']=False;save_json(BASE/'zalo_settings.json',cfg)
        google=config()
        for old,new in [('SPREADSHEET_ID','spreadsheet_id'),('SHEET_NAME','worksheet')]:
            if values.get(old):google[new]=values[old]
        save_json(BASE/'config.json',google)
        ai=zalo_ai.config()
        for old,new in [('OPENAI_API_KEY','api_key'),('OPENAI_MODEL','model')]:
            if values.get(old):ai[new]=values[old]
        save_json(BASE/'zalo_ai.json',ai)
    return {'ok':True,'message':'Đã nhập cấu hình nhóm/Sheet/AI từ tool cũ. Bot đang tắt; kiểm tra cấu hình và ghép người gửi trước khi bật.'}
@app.post('/api/google/credentials')
def import_google_key(file:UploadFile=File(...),u=Depends(local_owner)):
    data=file.file.read(65537)
    if len(data)>65536:raise HTTPException(400,'File khóa tối đa 64 KB.')
    try:
        key=json.loads(data)
        if key.get('type')!='service_account' or not key.get('private_key') or not key.get('client_email'):raise ValueError()
        from google.oauth2.service_account import Credentials
        Credentials.from_service_account_info(key)
    except Exception:raise HTTPException(400,'Chọn file JSON Service Account thật của tool cũ hoặc khóa Google đã tải.')
    with LOCK:save_json(BASE/'service_account.json',key)
    return {'ok':True,'message':'Đã lưu khóa Google vào app. Kiểm tra quyền chia sẻ Sheet rồi bấm Kiểm tra Sheet.'}

@app.get('/api/easy-setup')
def easy_setup_status(u=Depends(owner)):
    p=BASE/'easy_setup.json'
    return json.loads(p.read_text('utf8')) if p.exists() else {'done':False,'messages':[]}
@app.post('/api/easy-setup')
def easy_setup_run(u=Depends(local_owner)):
    raise HTTPException(403,'Thiết lập Zalo đang tạm dừng. Kết nối Google trong Cài đặt > Google.')
