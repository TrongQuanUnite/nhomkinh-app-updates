import datetime, hashlib, hmac, json, secrets, re, time
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException, Request, UploadFile, File, Form
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel, ConfigDict
import jwt
from store import BASE, FIELDS, LABELS, LOCK, store, config, save_json, norm
app=FastAPI(title='Nhật ký Nhôm Kính')
secret_path=BASE/'.session_secret'
if not secret_path.exists():secret_path.write_text(secrets.token_hex(32))
SECRET=secret_path.read_text()
def hash_password(password,salt=None):
    salt=salt or secrets.token_hex(16)
    return salt+':'+hashlib.pbkdf2_hmac('sha256',password.encode(),salt.encode(),260000).hex()
def check_password(password,stored):return hmac.compare_digest(hash_password(password,stored.split(':')[0]),stored)
def users():return json.loads((BASE/'users.json').read_text('utf8')) if (BASE/'users.json').exists() else {}
def public(u):return {k:v for k,v in u.items() if k!='password_hash'}
def user(request:Request):
    try:
        payload=jwt.decode(request.cookies.get('session',''),SECRET,algorithms=['HS256']);u=users().get(payload['sub'])
        if not u or payload.get('revision')!=u.get('revision'):raise ValueError()
        return u
    except Exception:raise HTTPException(401,'Vui lòng đăng nhập lại.')
def owner(u=Depends(user)):
    if u['role']!='chu':raise HTTPException(403,'Chỉ chủ xưởng được dùng chức năng này.')
    return u
def target(row,u,expected=None):
    p=next((p for p in store.rows() if p['row_index']==row),None)
    if not p:raise HTTPException(404,'Không tìm thấy công trình.')
    teams=[norm(s) for s in re.split(r'[,;/\n+&]',p['doi_truong'])]
    if u['role']!='chu' and norm(u.get('doi_truong','')) not in teams:raise HTTPException(403,'Công trình thuộc đội khác.')
    if expected and expected!=p['version']:raise HTTPException(409,'Dữ liệu đã thay đổi. Bấm Làm mới rồi cập nhật lại để tránh ghi đè.')
    return p
@app.middleware('http')
async def protection(request,call_next):
    if request.method in ['POST','PUT','DELETE']:
        origin=request.headers.get('origin')
        if origin and origin!=str(request.base_url).rstrip('/'):
            return JSONResponse({'detail':'Nguồn yêu cầu không hợp lệ.'},403)
        if request.headers.get('x-app-request')!='1':return JSONResponse({'detail':'Yêu cầu không hợp lệ.'},403)
    response=await call_next(request);response.headers['X-Content-Type-Options']='nosniff';response.headers['Cache-Control']='no-store';return response
@app.exception_handler(Exception)
async def error(request,exc):
    msg=str(exc) if isinstance(exc,ValueError) else 'Không kết nối được Google. Kiểm tra mạng, quyền chia sẻ, tên trang tính và cấu hình. Nếu tải ảnh, kiểm tra quyền thư mục và dung lượng Drive.'
    return JSONResponse({'detail':msg},503)
@app.get('/',response_class=HTMLResponse)
def home():return (BASE/'templates/index.html').read_text('utf8')
@app.get('/api/status')
def status():return {'setup_required':not users(),'mode':config()['mode']}
class Initial(BaseModel):password:str
@app.post('/api/setup')
def setup(body:Initial,request:Request):
    if request.client.host not in ['127.0.0.1','::1','testclient']:raise HTTPException(403,'Tạo tài khoản lần đầu trên máy chạy app: localhost:8000.')
    with LOCK:
        if users():raise HTTPException(409,'Đã tạo tài khoản chủ.')
        if len(body.password)<8:raise HTTPException(400,'Mật khẩu cần ít nhất 8 ký tự.')
        save_json(BASE/'users.json',{'chu':{'username':'chu','full_name':'Chủ xưởng','role':'chu','doi_truong':'','password_hash':hash_password(body.password),'revision':secrets.token_hex(8)}})
    return {'ok':True}
class Login(BaseModel):username:str;password:str;remember_me:bool=True
attempts={}
@app.post('/api/login')
def login(body:Login,request:Request):
    key=request.client.host;now=time.time();recent=[t for t in attempts.get(key,[]) if now-t<300];attempts[key]=recent
    if len(recent)>=10:raise HTTPException(429,'Thử lại sau 5 phút.')
    u=users().get(body.username.strip().lower())
    if not u or not check_password(body.password,u['password_hash']):recent.append(now);raise HTTPException(401,'Sai tài khoản hoặc mật khẩu.')
    attempts.pop(key,None);seconds=90*86400 if body.remember_me else 86400
    token=jwt.encode({'sub':u['username'],'revision':u['revision'],'exp':int(now)+seconds},SECRET,algorithm='HS256')
    res=JSONResponse(public(u));res.set_cookie('session',token,max_age=seconds if body.remember_me else None,httponly=True,samesite='strict',secure=request.url.scheme=='https');return res
@app.post('/api/logout')
def logout():
    res=JSONResponse({'ok':True});res.delete_cookie('session');return res
@app.get('/api/me')
def me(u=Depends(user)):return public(u)
@app.get('/api/projects')
def projects(u=Depends(user)):
    with LOCK:
        rows=store.rows()
        if u['role']=='chu':return rows
        return [p for p in rows if norm(u['doi_truong']) in [norm(s) for s in re.split(r'[,;/\n+&]',p['doi_truong'])]]
class Change(BaseModel):
    model_config=ConfigDict(extra='forbid')
    version:str
    data:dict[str,str]
@app.put('/api/projects/{row}')
def update(row:int,body:Change,u=Depends(user)):
    with LOCK:
        p=target(row,u,body.version)
        allowed=set(FIELDS)-{'hinh_anh'} if u['role']=='chu' else {'tien_do_bao_cao','ve_sinh','giao_chia_khoa','trang_thai','thieu_hang_muc','dinh_vi'}
        if not set(body.data)<=allowed:raise HTTPException(403,'Không được sửa trường này.')
        if any(len(v)>15000 for v in body.data.values()):raise HTTPException(400,'Nội dung quá dài.')
        data=body.data.copy()
        if data.get('dinh_vi'):
            from location_scanner import normalize_map_url
            data['dinh_vi']=normalize_map_url(data['dinh_vi'])
            if not data['dinh_vi']:raise HTTPException(400,'Định vị phải là link Google Maps hợp lệ.')
        if 'tien_do_bao_cao' in data:
            note=data['tien_do_bao_cao'].strip()
            data['tien_do_bao_cao']=(p['tien_do_bao_cao']+'\n['+datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=7))).strftime('%d/%m/%Y %H:%M')+' · '+u['full_name']+'] '+note).strip() if note else p['tien_do_bao_cao']
        store.update(row,data)
    return {'ok':True}
@app.post('/api/projects')
def create(data:dict[str,str],u=Depends(owner)):
    if not set(data)<=set(FIELDS)-{'hinh_anh'} or not data.get('ten_cong_trinh','').strip():raise HTTPException(400,'Kiểm tra tên và thông tin công trình.')
    with LOCK:store.create(data)
    return {'ok':True}
@app.post('/api/projects/{row}/media')
def media(row:int,version:str=Form(...),file:UploadFile=File(...),u=Depends(user)):
    with LOCK:
        p=target(row,u,version)
        if file.content_type not in {'image/jpeg','image/png','image/webp','image/heic','image/heif','video/mp4','video/quicktime','video/webm','video/3gpp'}:raise HTTPException(400,'Chỉ nhận ảnh hoặc video thông dụng.')
        file.file.seek(0,2);size=file.file.tell();file.file.seek(0)
        if size==0 or size>100*1024*1024:raise HTTPException(400,'File phải từ 1 byte đến 100 MB.')
        link=store.upload(file.file,file.filename or 'media',file.content_type,p['ten_cong_trinh'])
        try:store.update(row,{'hinh_anh':(p['hinh_anh']+'\n'+link).strip()})
        except Exception:raise HTTPException(503,'Đã tải Drive nhưng chưa ghi được Sheet. Giữ link này: '+link)
    return {'ok':True,'link':link}
@app.get('/api/config')
def get_config(u=Depends(owner)):return config()
@app.put('/api/config')
def put_config(data:dict[str,str],u=Depends(owner)):
    if set(data)!={'mode','spreadsheet_id','worksheet','drive_folder_id'} or data['mode'] not in ['demo','google']:raise HTTPException(400,'Cấu hình không hợp lệ.')
    for key in ['spreadsheet_id','drive_folder_id']:
        value=data[key];match=re.search(r'/(?:d|folders)/([a-zA-Z0-9_-]+)',value);data[key]=match.group(1) if match else value.strip()
    with LOCK:save_json(BASE/'config.json',data)
    return {'ok':True}
@app.post('/api/check-google')
def check(u=Depends(owner)):
    ws,_=store.connect();cols=store.columns(ws.row_values(1));missing=[LABELS[FIELDS.index(k)] for k in FIELDS if k not in cols];return {'ok':True,'message':'Đọc được Sheet. '+('Thiếu cột: '+', '.join(missing)+'. Bấm Bổ sung cột.' if missing else 'Đã đủ cột quản lý/Zalo.')+' Chưa kiểm tra tải ảnh.'}
@app.get('/api/users')
def list_users(u=Depends(owner)):return [public(x) for x in users().values()]
@app.post('/api/users')
def add_user(data:dict[str,str],u=Depends(owner)):
    name=data.get('username','').strip().lower();password=data.get('password','')
    if not re.fullmatch('[a-z0-9_]{2,30}',name) or name=='chu' or len(password)<8 or not data.get('doi_truong','').strip():raise HTTPException(400,'Tên tài khoản 2–30 ký tự a-z/0-9/_. Mật khẩu ít nhất 8 ký tự. Nhập đúng tên đội trong Sheet.')
    with LOCK:
        db=users()
        if name in db and db[name]['role']=='chu':raise HTTPException(403,'Không được thay tài khoản chủ bằng tài khoản thợ.')
        db[name]={'username':name,'full_name':data.get('full_name',name),'doi_truong':data['doi_truong'],'role':'tho','password_hash':hash_password(password),'revision':secrets.token_hex(8)};save_json(BASE/'users.json',db)
    return {'ok':True}

# Update settings are separate from Google config and are always preserved.
import updater, threading
update_lock=threading.Lock()
def local_owner(request:Request,u=Depends(owner)):
    if request.client.host not in ['127.0.0.1','::1','testclient']:raise HTTPException(403,'Cập nhật app trên máy chủ tại localhost:8000.')
    return u
@app.get('/api/update/status')
def update_status(u=Depends(owner)):
    p=BASE/'.updates/result.json'
    return {'current':updater.VERSION,'settings':updater.settings(),'result':json.loads(p.read_text('utf8')) if p.exists() else None}
@app.put('/api/update/settings')
def update_settings(data:dict[str,str],u=Depends(local_owner)):
    updater.set_repository(data.get('repository',''));return {'ok':True}
@app.post('/api/update/check')
def check_update(u=Depends(owner)):return updater.check()
@app.post('/api/update/install')
def install_update(u=Depends(local_owner)):
    callback=getattr(app.state,'restart_callback',None)
    if callback is None:raise HTTPException(400,'Chạy app bằng CHAY_UNG_DUNG.bat để tự khởi động lại khi cập nhật.')
    if not update_lock.acquire(blocking=False):raise HTTPException(409,'Đang chuẩn bị cập nhật, vui lòng chờ.')
    try:
        if (BASE/'.updates/pending.json').exists():
            job=json.loads((BASE/'.updates/pending.json').read_text('utf8'))
            timer=threading.Timer(2,callback);timer.daemon=True;timer.start()
            return {'ok':True,'job_id':job['job_id'],'message':'Gói đã tải xong. Đang tiếp tục khởi động lại để cài cập nhật.'}
        info=updater.check()
        if not info['available']:raise HTTPException(400,'Không có bản mới.')
        job_id=updater.stage(info['release'])
        timer=threading.Timer(2,callback);timer.daemon=True;timer.start()
        return {'ok':True,'job_id':job_id,'message':'Đã tải bản mới. App đang khởi động lại, giữ cửa sổ chạy mở.'}
    finally:update_lock.release()

import preferences
@app.get('/api/options')
def get_options(u=Depends(user)):return preferences.get_options()
@app.put('/api/options')
def put_options(data:dict[str,list[str]],u=Depends(owner)):
    with LOCK:preferences.put_options(data)
    return {'ok':True}

import zalo_integration as zalo
@app.get('/api/zalo/settings')
def zalo_settings(u=Depends(owner)):return zalo.settings()
@app.put('/api/zalo/settings')
def save_zalo_settings(data:dict,u=Depends(local_owner)):
    if set(data)!=set(zalo.DEFAULT) or not isinstance(data['senders'],dict) or not isinstance(data['enabled'],bool) or not isinstance(data['auto_apply'],bool):raise HTTPException(400,'Cấu hình Zalo không hợp lệ.')
    if not isinstance(data['location_enabled'],bool) or not isinstance(data['reminders_enabled'],bool) or not isinstance(data['location_group_name'],str) or not isinstance(data['reminder_recipient'],str) or len(data['location_group_name'])>200 or len(data['reminder_recipient'])>200:raise HTTPException(400,'Cấu hình định vị/nhắc lịch không hợp lệ.')
    if data['location_enabled'] and not data['location_group_name'].strip():raise HTTPException(400,'Nhập tên nhóm định vị.')
    if not isinstance(data['mention'],str) or not re.fullmatch(r'[\w -]{1,40}',data['mention']) or not isinstance(data['group_name'],str) or len(data['group_name'])>200:raise HTTPException(400,'Kiểm tra tên nhóm và tên gọi bot.')
    if data['enabled'] and not data['group_name'].strip():raise HTTPException(400,'Nhập tên nhóm công việc.')
    db=users()
    if any(not isinstance(k,str) or not k.strip() or v not in db for k,v in data['senders'].items()):raise HTTPException(400,'Tên Zalo cần ghép với tài khoản web có sẵn.')
    with LOCK:save_json(BASE/'zalo_settings.json',data)
    if data['enabled'] and 'bot_manager' in globals():bot_manager.resume()
    return {'ok':True}
@app.get('/api/zalo/events')
def zalo_events(u=Depends(owner)):return list(reversed(zalo.queue()))[:100]
@app.post('/api/zalo/events/{event_id}/approve')
def approve_zalo(event_id:str,data:dict,u=Depends(owner)):
    with LOCK:
        events=zalo.queue();event=next((e for e in events if e['id']==event_id),None)
        if not event or event['status']!='pending':raise HTTPException(409,'Báo cáo không còn chờ duyệt.')
        reply=zalo.apply(event,int(data.get('project_id',0)),u);zalo.save_events(events)
    return {'ok':True,'message':reply}
@app.post('/api/zalo/events/{event_id}/reject')
def reject_zalo(event_id:str,u=Depends(owner)):
    with LOCK:
        events=zalo.queue();event=next((e for e in events if e['id']==event_id),None)
        if not event or event['status']!='pending':raise HTTPException(409,'Báo cáo không còn chờ duyệt.')
        event['status']='rejected';zalo.save_events(events)
    return {'ok':True}
@app.post('/api/zalo/bridge')
def zalo_bridge(data:dict,request:Request):
    auth=request.headers.get('Authorization','')
    if request.client.host not in ['127.0.0.1','::1','testclient'] or not hmac.compare_digest(auth,'Bearer '+zalo.token()):raise HTTPException(403,'Bridge chưa được xác thực.')
    return zalo.receive(data)

import zalo_ai
@app.get('/api/zalo/ai')
def get_zalo_ai(u=Depends(owner)):return zalo_ai.public_config()
@app.put('/api/zalo/ai')
def put_zalo_ai(data:dict,u=Depends(local_owner)):
    with LOCK:zalo_ai.save_config(data)
    return {'ok':True}


# Lifecycle also applies when launched by uvicorn directly.
from bot_manager import manager as bot_manager
@app.on_event('startup')
def start_integrated_bot():bot_manager.start_supervisor()
@app.on_event('shutdown')
def stop_integrated_bot():bot_manager.close()
@app.get('/api/zalo/runtime')
def zalo_runtime(u=Depends(owner)):return bot_manager.snapshot()
@app.post('/api/zalo/start')
def start_zalo(u=Depends(local_owner)):
    cfg=zalo.settings()
    if not cfg['group_name']:raise HTTPException(400,'Lưu tên nhóm và ghép tài khoản trước.')
    cfg['enabled']=True
    with LOCK:save_json(BASE/'zalo_settings.json',cfg)
    bot_manager.resume();return {'ok':True}
@app.post('/api/zalo/stop')
def stop_zalo(u=Depends(local_owner)):
    cfg=zalo.settings();cfg['enabled']=False
    with LOCK:save_json(BASE/'zalo_settings.json',cfg)
    bot_manager.pause();return {'ok':True}

@app.post('/api/prepare-columns')
def prepare_columns(u=Depends(owner)):
    with LOCK:added=store.prepare_columns()
    return {'ok':True,'message':'Đã thêm cột: '+', '.join(added) if added else 'Không cần thêm cột. Các cột hiện có được giữ nguyên.'}

def require_bridge(request):
    if request.client.host not in ['127.0.0.1','::1','testclient'] or not hmac.compare_digest(request.headers.get('Authorization',''),'Bearer '+zalo.token()):raise HTTPException(403,'Bridge chưa được xác thực.')
@app.post('/api/zalo/location')
def bridge_location(data:dict,request:Request):
    require_bridge(request);return zalo.receive_location(data)
@app.post('/api/zalo/reminders')
def bridge_reminders(request:Request):
    require_bridge(request)
    import zalo_reminders
    return zalo_reminders.due()
@app.post('/api/zalo/reminders/{key}/sent')
def bridge_reminder_sent(key:str,request:Request):
    require_bridge(request)
    import zalo_reminders
    zalo_reminders.acknowledge(key);return {'ok':True}
@app.post('/api/zalo/import-config')
def import_old_zalo(file:UploadFile=File(...),u=Depends(local_owner)):
    data=file.file.read(65537)
    if len(data)>65536:raise HTTPException(400,'File cấu hình tối đa 64 KB.')
    values={}
    for line in data.decode('utf-8-sig').splitlines():
        line=line.strip()
        if not line or line.startswith('#') or '=' not in line:continue
        k,v=line.split('=',1);values[k.strip()]=v.strip().strip('"').strip("'")
    with LOCK:
        cfg=zalo.settings()
        for old,new in [('MAIN_GROUP_NAME','group_name'),('LOCATION_GROUP_NAME','location_group_name'),('REMINDER_MENTION_NAME','reminder_recipient')]:
            if values.get(old):cfg[new]=values[old]
        cfg['enabled']=False;save_json(BASE/'zalo_settings.json',cfg)
        google=config()
        for old,new in [('SPREADSHEET_ID','spreadsheet_id'),('SHEET_NAME','worksheet')]:
            if values.get(old):google[new]=values[old]
        save_json(BASE/'config.json',google)
        ai=zalo_ai.config()
        for old,new in [('OPENAI_API_KEY','api_key'),('OPENAI_MODEL','model')]:
            if values.get(old):ai[new]=values[old]
        save_json(BASE/'zalo_ai.json',ai)
    return {'ok':True,'message':'Đã nhập cấu hình nhóm/Sheet/AI từ tool cũ. Bot đang tắt; kiểm tra cấu hình và ghép người gửi trước khi bật.'}
@app.post('/api/google/credentials')
def import_google_key(file:UploadFile=File(...),u=Depends(local_owner)):
    data=file.file.read(65537)
    if len(data)>65536:raise HTTPException(400,'File khóa tối đa 64 KB.')
    try:
        key=json.loads(data)
        if key.get('type')!='service_account' or not key.get('private_key') or not key.get('client_email'):raise ValueError()
        from google.oauth2.service_account import Credentials
        Credentials.from_service_account_info(key)
    except Exception:raise HTTPException(400,'Chọn file JSON Service Account thật của tool cũ hoặc khóa Google đã tải.')
    with LOCK:save_json(BASE/'service_account.json',key)
    return {'ok':True,'message':'Đã lưu khóa Google vào app. Kiểm tra quyền chia sẻ Sheet rồi bấm Kiểm tra Sheet.'}

@app.get('/api/easy-setup')
def easy_setup_status(u=Depends(owner)):
    p=BASE/'easy_setup.json'
    return json.loads(p.read_text('utf8')) if p.exists() else {'done':False,'messages':[]}
@app.post('/api/easy-setup')
def easy_setup_run(u=Depends(local_owner)):
    import easy_setup
    with LOCK:messages=easy_setup.configure()
    if zalo.settings()['enabled']:bot_manager.resume()
    return {'done':True,'messages':messages}
