"""Append-only reports keyed by persistent project ID, never by Sheet row."""
import datetime,json,secrets
from store import BASE,save_json,store

def project_id(project,data):
    uid=project.get('cong_trinh_id') or secrets.token_hex(16)
    if project.get('cong_trinh_id') and sum(p.get('cong_trinh_id')==uid for p in store.rows())>1:
        raise ValueError('Mã công trình bị trùng do sao chép dòng Sheet. Chủ cần xóa mã ở dòng bản sao rồi thử lại.')
    data['cong_trinh_id']=uid
    return uid

def database():
    path=BASE/'reports.json'
    return json.loads(path.read_text('utf8')) if path.exists() else {}

def append(uid,project,user,text,attachments=None):
    db=database();entries=db.setdefault(uid,[])
    if not entries and project.get('tien_do_bao_cao'):
        entries.append({'id':secrets.token_hex(12),'author':'Lịch sử trước nâng cấp','username':'','time':'','text':project['tien_do_bao_cao'],'attachments':[]})
    entry={'id':secrets.token_hex(12),'author':user['full_name'],'username':user['username'],
           'time':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=7))).isoformat(timespec='seconds'),
           'text':text,'attachments':attachments or []}
    entries.append(entry);save_json(BASE/'reports.json',db)
    return entry

def list_reports(project):
    return database().get(project.get('cong_trinh_id',''),[])
