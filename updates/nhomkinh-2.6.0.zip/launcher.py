import os,socket,threading,webbrowser,time,subprocess,sys,secrets,signal,json
from pathlib import Path
BASE=Path(__file__).resolve().parent

def open_browser():
    for _ in range(60):
        try:
            with socket.create_connection(('127.0.0.1',8000),timeout=1):pass
            webbrowser.open('http://localhost:8000');return
        except OSError:time.sleep(.5)
def worker():
    import uvicorn,main
    server=uvicorn.Server(uvicorn.Config(main.app,host='0.0.0.0',port=8000))
    main.app.state.restart_callback=lambda:setattr(server,'should_exit',True)
    def stop_watcher():
        while not server.should_exit:
            from process_utils import alive
            if (BASE/'.app_stop').exists() or not alive(os.environ.get('NK_APP_PARENT_PID')):server.should_exit=True;return
            time.sleep(.5)
    threading.Thread(target=stop_watcher,daemon=True).start()
    server.run()
def kill_tree(pid):
    if os.name=='nt':subprocess.run(['taskkill','/PID',str(pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    else:
        try:os.killpg(pid,signal.SIGTERM)
        except ProcessLookupError:pass

def supervise():
    try:
        with socket.socket() as s:s.bind(('0.0.0.0',8000))
    except OSError:
        print('Cong 8000 dang duoc su dung. Dong app cu truoc khi chay ban nay.');return
    if (BASE/'.updates/pending.json').exists():
        print('Dang hoan tat ban cap nhat da tai...')
        result=subprocess.run([sys.executable,'-c','from updater import apply_pending; apply_pending()'],cwd=BASE)
        if result.returncode:
            print('Chua cai duoc ban cap nhat. Chup cua so nay de kiem tra.');return
    print('\nNhom Kinh + Zalo: chi can cua so nay.')
    print('May tinh: http://localhost:8000')
    for ip in sorted(set(socket.gethostbyname_ex(socket.gethostname())[2])):
        if not ip.startswith('127.'):print('Dien thoai cung WiFi: http://'+ip+':8000')
    print('Ctrl+C de dong ca web va bot. Cap nhat se tu khoi dong lai ca hai.\n')
    threading.Thread(target=open_browser,daemon=True).start()
    while True:
        (BASE/'.app_stop').unlink(missing_ok=True)
        nonce=secrets.token_hex(16);env=os.environ.copy();env['NK_APP_SESSION']=nonce;env['NK_APP_PARENT_PID']=str(os.getpid())
        kw={'cwd':BASE,'env':env}
        if os.name=='nt':kw['creationflags']=subprocess.CREATE_NEW_PROCESS_GROUP
        else:kw['start_new_session']=True
        child=subprocess.Popen([sys.executable,str(BASE/'launcher.py'),'--worker'],**kw)
        try:child.wait()
        except KeyboardInterrupt:
            print('Dang dong Zalo va web...')
            (BASE/'.app_stop').write_text('stop')
            try:child.wait(timeout=60)
            except subprocess.TimeoutExpired:
                state=BASE/'zalo_process.json'
                try:
                    info=json.loads(state.read_text())
                    if info.get('session')==nonce:kill_tree(int(info['pid']))
                except (OSError,ValueError,KeyError):pass
                kill_tree(child.pid);child.wait(timeout=10)
            break
        if not (BASE/'.updates/pending.json').exists():break
        print('Dang cap nhat, vui long giu cua so mo...')
        result=subprocess.run([sys.executable,'-c','from updater import apply_pending; apply_pending()'],cwd=BASE)
        if result.returncode:
            print('Cap nhat bi gian doan. Chup cua so nay de kiem tra.');break
if __name__=='__main__':
    if '--worker' in sys.argv:worker()
    else:supervise()
