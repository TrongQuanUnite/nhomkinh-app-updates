"""Consume a private local setup file; never distribute it in public releases."""
import hashlib,json,secrets,shutil
from store import BASE,LOCK,save_json

def apply():
    path=BASE/'owner_setup.json'
    if not path.exists():return
    with LOCK:
        payload=json.loads(path.read_text('utf8'))
        name=str(payload.get('username','')).strip().lower();password=payload.get('password','')
        if name!='trithanh' or not isinstance(password,str) or len(password)<8:raise ValueError('File thiết lập chủ không hợp lệ.')
        users_path=BASE/'users.json';db=json.loads(users_path.read_text('utf8')) if users_path.exists() else {}
        if name in db and db[name].get('role')!='chu':raise ValueError('Tên chủ trùng tài khoản thợ; đổi tài khoản thợ này trước.')
        if users_path.exists():shutil.copy2(users_path,BASE/'users.before_owner_setup.json')
        old_names=[k for k,v in db.items() if v.get('role')=='chu']
        for key in old_names:db.pop(key)
        salt=secrets.token_hex(16)
        db[name]={'username':name,'full_name':payload.get('full_name','Trí Thành'),'role':'chu','doi_truong':'','status':'active','permissions':[],
                  'password_hash':salt+':'+hashlib.pbkdf2_hmac('sha256',password.encode(),salt.encode(),260000).hex(),'revision':secrets.token_hex(8)}
        save_json(users_path,db)
        settings_path=BASE/'zalo_settings.json'
        if settings_path.exists():
            cfg=json.loads(settings_path.read_text('utf8'));cfg['senders']={k:name if v in old_names else v for k,v in cfg.get('senders',{}).items()};save_json(settings_path,cfg)
        path.unlink()
