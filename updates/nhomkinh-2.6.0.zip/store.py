import json, re, unicodedata, hashlib, threading
from pathlib import Path
BASE=Path(__file__).resolve().parent
LOCK=threading.RLock()
FIELDS=['thoi_gian','ten_cong_trinh','nguoi_do','lap_lay_ngay','doi_truong','khung_bao_ve','cau_thang_lan_can','bep','xuong','kinh','tien_do_bao_cao','ve_sinh','giao_chia_khoa','trang_thai','hinh_anh']
EXTRA_FIELDS=['lich_lap_dat','thanh_vien','thieu_hang_muc','dinh_vi']
FIELDS+=EXTRA_FIELDS
LABELS=['Thời Gian','Tên Công Trình','Người Đo','Lắp Lấy Ngày','Đội Trưởng','Khung Bảo Vệ','Cầu Thang / Lan Can','Bếp','Xưởng','Kính','Tiến Độ / Báo Cáo','Vệ Sinh','Giao Chìa Khóa','Trạng Thái','Hình Ảnh / Clip']
LABELS+=['Lịch Lắp Đặt','Thành Viên','Thiếu Hạng Mục','Định Vị']
from workflow import WORKFLOW,NOTE_FIELDS
for key,label in WORKFLOW:
    if key not in FIELDS:FIELDS.append(key);LABELS.append(('Sản xuất - ' if key.startswith('sx_') else 'Lắp đặt - ' if key.startswith('ld_') else '')+label)
for key in NOTE_FIELDS:
    FIELDS.append(key);LABELS.append(LABELS[FIELDS.index(key[:-8])]+' - Ghi chú')
FIELDS.append('cong_trinh_id');LABELS.append('Mã công trình app')
def norm(s):
    return re.sub(r'[^a-z0-9]','',unicodedata.normalize('NFD',str(s).lower().replace('đ','d')).encode('ascii','ignore').decode())
def config():
    p=BASE/'config.json'
    return json.loads(p.read_text('utf8')) if p.exists() else {'mode':'demo','spreadsheet_id':'1XNR4PDDcZ_ennxWHladDwKxay3XGTucB42TI-qe5lr0','worksheet':'NHAT_KY','drive_folder_id':''}
def save_json(path,data):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),'utf8');temp.replace(path)
def version(p):
    return hashlib.sha256(json.dumps({k:p.get(k,'') for k in FIELDS},sort_keys=True,ensure_ascii=False).encode()).hexdigest()
class Store:
    def connect(self):
        import gspread
        from google.oauth2 import service_account
        from google.oauth2.credentials import Credentials
        from google.auth.transport.requests import Request
        c=config()
        token=BASE/'google_token.json'
        if token.exists():
            creds=Credentials.from_authorized_user_file(str(token))
            if creds.expired and creds.refresh_token:
                creds.refresh(Request());token.write_text(creds.to_json(),'utf8')
        elif (BASE/'service_account.json').exists():
            creds=service_account.Credentials.from_service_account_file(str(BASE/'service_account.json'),scopes=['https://www.googleapis.com/auth/spreadsheets','https://www.googleapis.com/auth/drive'])
        else: raise ValueError('Chưa có khóa Google. Đặt service_account.json vào thư mục app hoặc chạy KET_NOI_GOOGLE.bat.')
        ws=gspread.authorize(creds).open_by_key(c['spreadsheet_id']).worksheet(c['worksheet'])
        return ws,creds
    def rows(self):
        if config()['mode']=='demo':
            path=BASE/'demo.json'
            if not path.exists():
                data=[]
                for i,(name,team) in enumerate([('Nhà anh Minh — cửa nhôm kính','Khang mập'),('Nhà chị Lan — lan can cầu thang','Thái')],2):
                    p=dict.fromkeys(FIELDS,'');p.update(row_index=i,ten_cong_trinh=name,doi_truong=team,xuong='Đang sản xuất',kinh='Chưa đặt',trang_thai='Đang thực hiện',thoi_gian='08/10/2026');data.append(p)
                save_json(path,data)
            data=json.loads(path.read_text('utf8'))
        else:
            ws,_=self.connect(); values=ws.get_all_values();cols=self.columns(values[0] if values else [])
            data=[dict({k:r[cols[k]] if k in cols and cols[k]<len(r) else '' for k in FIELDS},row_index=i) for i,r in enumerate(values[1:],2) if cols['ten_cong_trinh']<len(r) and r[cols['ten_cong_trinh']].strip()]
        for p in data:
            for k in FIELDS:p.setdefault(k,'')
            p['version']=version(p)
        return data
    def columns(self,headers):
        lookup={norm(x):i for i,x in enumerate(headers)};out={}
        aliases={'tien_do_bao_cao':['Tiến Độ','Báo Cáo'],'cau_thang_lan_can':['Cầu Thang','Lan Can'],'hinh_anh':['Hình Ảnh','Ảnh / Clip']}
        for k,label in zip(FIELDS,LABELS):
            match=next((lookup[norm(x)] for x in [label]+aliases.get(k,[]) if norm(x) in lookup),None)
            if match is not None:out[k]=match
        if 'ten_cong_trinh' not in out:raise ValueError('Dòng 1 thiếu cột Tên Công Trình. App dừng để tránh ghi nhầm.')
        return out
    def update(self,row,data):
        if config()['mode']=='demo':
            rows=self.rows();p=next(p for p in rows if p['row_index']==row);p.update(data);save_json(BASE/'demo.json',rows)
        else:
            import gspread
            ws,_=self.connect();cols=self.columns(ws.row_values(1))
            missing=[k for k in data if k not in cols]
            if missing:
                self.prepare_columns();cols=self.columns(ws.row_values(1))
            ws.update_cells([gspread.Cell(row,cols[k]+1,str(v)) for k,v in data.items()],value_input_option='RAW')
    def create(self,data):
        if config()['mode']=='demo':
            rows=self.rows();p=dict.fromkeys(FIELDS,'');p.update(data,row_index=max([r['row_index'] for r in rows]+[1])+1);rows.append(p);save_json(BASE/'demo.json',rows)
        else:
            self.prepare_columns();ws,_=self.connect();cols=self.columns(ws.row_values(1));row=['']*(max(cols.values())+1)
            for k,v in data.items():
                if k not in cols and v:raise ValueError('Sheet thiếu cột '+LABELS[FIELDS.index(k)]+'. Bấm Bổ sung cột trước.')
                if k in cols:row[cols[k]]=v
            ws.append_row(row,value_input_option='RAW')
    def delete(self,row):
        if config()['mode']=='demo':
            rows=self.rows();save_json(BASE/'demo.json',[p for p in rows if p['row_index']!=row])
        else:
            ws,_=self.connect();ws.delete_rows(row)
    def prepare_columns(self):
        if config()['mode']=='demo':return []
        ws,_=self.connect();headers=ws.row_values(1);cols=self.columns(headers)
        missing=[LABELS[FIELDS.index(k)] for k in FIELDS if k not in cols]
        if missing:
            import gspread
            if len(headers)+len(missing)>ws.col_count:ws.add_cols(len(headers)+len(missing)-ws.col_count)
            ws.update_cells([gspread.Cell(1,len(headers)+i+1,label) for i,label in enumerate(missing)],value_input_option='RAW')
        return missing
    def upload(self,file,name,mime,project):
        if config()['mode']=='demo':raise ValueError('Chế độ dùng thử chưa tải lên Drive. Kết nối Google để dùng ảnh/clip.')
        from googleapiclient.discovery import build
        from googleapiclient.http import MediaIoBaseUpload
        _,creds=self.connect();folder=config()['drive_folder_id']
        if not folder:raise ValueError('Chưa nhập thư mục Google Drive trong Cấu hình.')
        drive=build('drive','v3',credentials=creds,cache_discovery=False)
        meta=drive.files().get(fileId=folder,fields='id,mimeType,driveId',supportsAllDrives=True).execute()
        if meta['mimeType']!='application/vnd.google-apps.folder':raise ValueError('Đường dẫn Drive phải là thư mục.')
        if hasattr(creds,'service_account_email') and not meta.get('driveId'):
            raise ValueError('Gmail cá nhân: chạy KET_NOI_GOOGLE.bat để tải ảnh bằng tài khoản Google. Service Account chỉ tải được vào Shared Drive của Workspace.')
        result=drive.files().create(body={'name':f'[{project}] {Path(name).name}','parents':[folder]},media_body=MediaIoBaseUpload(file,mimetype=mime,resumable=True),fields='id,webViewLink',supportsAllDrives=True).execute()
        return result.get('webViewLink','https://drive.google.com/file/d/'+result['id']+'/view')
store=Store()
