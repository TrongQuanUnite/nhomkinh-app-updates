"""Four tab grants. Field access is derived centrally, including notes."""
from store import FIELDS
from workflow import PLAN,PRODUCTION,INSTALLATION
TAB_FIELDS={
 'plan':{k for k,_ in PLAN}|{'doi_truong','thanh_vien','lich_lap_dat','trang_thai','thieu_hang_muc'},
 'production':{k for k,_ in PRODUCTION}|{'xuong','kinh','khung_bao_ve','cau_thang_lan_can','bep'},
 'installation':{k for k,_ in INSTALLATION}|{'tien_do_bao_cao','hinh_anh'},
 'location':{'dinh_vi'}}
EDITABLE_FIELDS=set(FIELDS)-{'hinh_anh','thoi_gian','cong_trinh_id'}
PERMISSION_FIELDS=set(TAB_FIELDS)
def tab_permissions(user):
    if user.get('role')=='chu':return set(TAB_FIELDS)
    if user.get('status','active')!='active':return set()
    raw=user.get('permissions',[])
    if not isinstance(raw,list):return set()
    granted={k for k in raw if isinstance(k,str)}
    # Previously saved field grants become the corresponding tab grant.
    return {tab for tab,fields in TAB_FIELDS.items() if tab in granted or fields & granted}
def editable_fields(user):
    if user.get('role')=='chu':return EDITABLE_FIELDS.copy()
    fields=set().union(*(TAB_FIELDS[tab] for tab in tab_permissions(user))) if tab_permissions(user) else set()
    fields|={k+'_ghi_chu' for k in fields if k+'_ghi_chu' in EDITABLE_FIELDS}
    return fields & EDITABLE_FIELDS
def can_upload(user):
    return 'installation' in tab_permissions(user)
