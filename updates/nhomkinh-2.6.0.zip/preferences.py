from store import BASE,save_json,LOCK
import json
OPTIONS={'thanh_vien':['Quân','Trung','Anh Thành'],'nguoi_do':['Quân','Trung','Anh Thành'],'doi_truong':['Khang mập','Thái','Tuấn','Vỹ'],'xuong':['Chưa làm','Đang sản xuất','Đã xong'],'kinh':['Chưa đặt','Đã đặt','Đã có kính','Cần đặt lại'],'khung_bao_ve':['Không có','Chưa làm','Đang làm','Đã xong'],'cau_thang_lan_can':['Không có','Chưa làm','Đang làm','Đã xong'],'bep':['Không có','Chưa làm','Đang làm','Đã xong'],'ve_sinh':['Chưa','Rồi'],'giao_chia_khoa':['Chưa giao','Đã giao'],'trang_thai':['Đang thực hiện','Có phát sinh','Hoàn thành']}
from workflow import WORKFLOW,PRODUCTION,INSTALLATION
for key,label in WORKFLOW:OPTIONS.setdefault(key,[])
for key in ['lich_lap_dat','thieu_hang_muc']:OPTIONS.setdefault(key,[])
for key,label in PRODUCTION+INSTALLATION:OPTIONS[key]=['Chưa Làm','Đang Làm','Hoàn Thành']
def get_options():
    with LOCK:return _get_options()
def _get_options():
    p=BASE/'options.json'
    data=json.loads(p.read_text('utf8')) if p.exists() else {}
    if not data.get('_installation_defaults_v1'):
        legacy={'ve_sinh':['Chưa','Rồi'],'giao_chia_khoa':['Chưa giao','Đã giao']}
        for k,_ in INSTALLATION:
            if not data.get(k) or data.get(k)==legacy.get(k):data[k]=OPTIONS[k].copy()
        data['_installation_defaults_v1']=True
        save_json(p,data)
    return {k:data.get(k,v) for k,v in OPTIONS.items()}
def put_options(data):
    if set(data)!=set(OPTIONS):raise ValueError('Danh sách mục không hợp lệ.')
    for k,values in data.items():
        if not isinstance(values,list) or len(values)>100 or any(not isinstance(v,str) or not v.strip() or len(v)>150 for v in values):raise ValueError('Mỗi mục tối đa 100 tùy chọn, mỗi tùy chọn 1–150 ký tự.')
        data[k]=list(dict.fromkeys(v.strip() for v in values))
    save_json(BASE/'options.json',dict(data,_installation_defaults_v1=True))
