"""One-time migration from nearby legacy apps. Never overwrites existing settings."""
import json
from pathlib import Path
from store import BASE, save_json, config, store

def candidates():
    roots=[BASE,BASE.parent/'AI Zalo',BASE/'AI Zalo',BASE.parent/'AI Zalo(1)']
    return [p for p in roots if (p/'.env').is_file()]

def configure():
    result=[]
    import zalo_integration as zalo
    import zalo_ai
    roots=candidates()
    if len(roots)>1:
        return ['Có nhiều tool cũ. Vào tab Zalo chọn đúng file .env để nhập.']
    if roots:
        root=roots[0]
        values={}
        raw=(root/'.env').read_bytes()
        if len(raw)>65536:raise ValueError('File .env quá lớn.')
        for line in raw.decode('utf-8-sig').splitlines():
            if '=' in line and not line.lstrip().startswith('#'):
                k,v=line.split('=',1);values[k.strip()]=v.strip().strip('\"').strip("'")
        if not (BASE/'zalo_settings.json').exists():
            z=zalo.settings()
            for old,new in [('MAIN_GROUP_NAME','group_name'),('LOCATION_GROUP_NAME','location_group_name'),('REMINDER_MENTION_NAME','reminder_recipient')]:
                if values.get(old):z[new]=values[old]
            save_json(BASE/'zalo_settings.json',z);result.append('Đã lấy tên nhóm Zalo từ tool cũ.')
        if not (BASE/'config.json').exists():
            c=config()
            for old,new in [('SPREADSHEET_ID','spreadsheet_id'),('SHEET_NAME','worksheet')]:
                if values.get(old):c[new]=values[old]
            save_json(BASE/'config.json',c)
        if not (BASE/'zalo_ai.json').exists():
            ai=zalo_ai.config()
            for old,new in [('OPENAI_API_KEY','api_key'),('OPENAI_MODEL','model')]:
                if values.get(old):ai[new]=values[old]
            # Keep AI disabled until the owner chooses to send reports to OpenAI.
            save_json(BASE/'zalo_ai.json',ai)
        if not (BASE/'service_account.json').exists():
            source=root/'credentials.json'
            if source.is_file() and source.stat().st_size<=65536:
                key=json.loads(source.read_text('utf-8-sig'))
                if key.get('type')=='service_account':
                    from google.oauth2.service_account import Credentials
                    Credentials.from_service_account_info(key)
                    save_json(BASE/'service_account.json',key);result.append('Đã lấy khóa Google.')
    c=config()
    if (BASE/'service_account.json').exists() or (BASE/'google_token.json').exists():
        previous=c.copy();c['mode']='google';save_json(BASE/'config.json',c)
        try:
            store.rows();added=store.prepare_columns()
            result.append('Google Sheet đã kết nối'+(' và bổ sung cột còn thiếu.' if added else '.'))
        except Exception:
            save_json(BASE/'config.json',previous)
            result.append('Chưa kết nối được Sheet. Kiểm tra quyền chia sẻ trong Cài đặt > Google.')
    else:result.append('Chưa có khóa Google: chọn JSON ở Cài đặt > Google một lần.')
    cfg=zalo.settings()
    if cfg['group_name']:
        cfg['enabled']=True;save_json(BASE/'zalo_settings.json',cfg)
        result.append('Đang mở Zalo. Quét QR nếu được yêu cầu.')
    else:result.append('Chưa có nhóm Zalo: nhập tên nhóm trong tab Zalo rồi bật bot.')
    save_json(BASE/'easy_setup.json',{'done':True,'messages':result})
    return result
