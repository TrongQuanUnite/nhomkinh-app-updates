"""Install dependencies only when requirements change, using this venv's Python."""
import hashlib,subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
if __name__=='__main__':
    req=BASE/'requirements.txt';marker=BASE/'.venv'/'requirements.sha256';digest=hashlib.sha256(req.read_bytes()).hexdigest()
    if marker.exists() and marker.read_text().strip()==digest:raise SystemExit(0)
    print('Dang cai/cap nhat thu vien. Lan dau can Internet...')
    result=subprocess.run([sys.executable,'-m','pip','install','-r',str(req)],cwd=BASE)
    if result.returncode:raise SystemExit(result.returncode)
    marker.parent.mkdir(exist_ok=True);marker.write_text(digest)
