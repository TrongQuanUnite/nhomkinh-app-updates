from store import BASE,save_json
import json
OPTIONS={'thanh_vien':['Quân','Trung','Anh Thành'],'nguoi_do':['Quân','Trung','Anh Thành'],'doi_truong':['Khang mập','Thái','Tuấn','Vỹ'],'xuong':['Chưa làm','Đang sản xuất','Đã xong'],'kinh':['Chưa đặt','Đã đặt','Đã có kính','Cần đặt lại'],'khung_bao_ve':['Không có','Chưa làm','Đang làm','Đã xong'],'cau_thang_lan_can':['Không có','Chưa làm','Đang làm','Đã xong'],'bep':['Không có','Chưa làm','Đang làm','Đã xong'],'ve_sinh':['Chưa','Rồi'],'giao_chia_khoa':['Chưa giao','Đã giao'],'trang_thai':['Đang thực hiện','Có phát sinh','Hoàn thành']}
def get_options():
    p=BASE/'options.json'
    data=json.loads(p.read_text('utf8')) if p.exists() else {}
    return {k:data.get(k,v) for k,v in OPTIONS.items()}
def put_options(data):
    if set(data)!=set(OPTIONS):raise ValueError('Danh sách mục không hợp lệ.')
    for k,values in data.items():
        if not isinstance(values,list) or len(values)>100 or any(not isinstance(v,str) or not v.strip() or len(v)>150 for v in values):raise ValueError('Mỗi mục tối đa 100 tùy chọn, mỗi tùy chọn 1–150 ký tự.')
        data[k]=list(dict.fromkeys(v.strip() for v in values))
    save_json(BASE/'options.json',data)
