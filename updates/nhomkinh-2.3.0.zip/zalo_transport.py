
import time
from collections import deque


_RECENT_SENT_MESSAGES = deque(maxlen=200)


def _clean_message_text(value: str) -> str:
    return " ".join(
        str(value or "")
        .replace("\u200b", "")
        .split()
    ).strip()


def remember_sent_message(content: str) -> None:
    cleaned = _clean_message_text(content)

    if cleaned:
        _RECENT_SENT_MESSAGES.append(
            (cleaned, time.time())
        )


def is_recent_sent_message(content: str) -> bool:
    cleaned = _clean_message_text(content)

    if not cleaned:
        return False

    now = time.time()

    while (
        _RECENT_SENT_MESSAGES
        and now - _RECENT_SENT_MESSAGES[0][1] > 180
    ):
        _RECENT_SENT_MESSAGES.popleft()

    for sent_text, _ in reversed(_RECENT_SENT_MESSAGES):
        if cleaned == sent_text:
            return True

        # Tin mention Zalo có thể thêm tên người ở đầu.
        if sent_text in cleaned and len(sent_text) >= 12:
            return True

    return False


def find_input_box(page):
    selectors = [
        "#richInput",
        "[contenteditable='true'][role='textbox']",
        "[contenteditable='true'][data-placeholder*='Nhập']",
        "[contenteditable='true'][aria-label*='Nhập']",
        ".chat-input [contenteditable='true']",
    ]

    for selector in selectors:
        locator = page.locator(selector)

        for index in range(locator.count() - 1, -1, -1):
            item = locator.nth(index)
            try:
                if item.is_visible():
                    return item
            except Exception:
                continue

    return None


def switch_to_group(page, group_name: str) -> bool:
    exact = page.get_by_text(group_name, exact=True)

    for index in range(exact.count()):
        item = exact.nth(index)
        try:
            if item.is_visible():
                item.click()
                time.sleep(1.2)
                return True
        except Exception:
            continue

    return False


def read_visible_messages(page) -> list[dict]:
    """
    Đọc tin nhắn đang hiển thị.

    Không dùng vị trí theo toàn màn hình để đo incoming/outgoing,
    vì Zalo có sidebar làm lệch tọa độ.
    """
    messages = page.evaluate(
        """
        () => {
            const clean = value =>
                String(value || "")
                    .replace(/\\u200B/g, "")
                    .replace(/\\s+/g, " ")
                    .trim();

            const nodes = Array.from(
                document.querySelectorAll(
                    ".text-message__container .text, " +
                    ".text-message_container .text"
                )
            );

            return nodes.map((node, index) => {
                const root =
                    node.closest(".chat-message") ||
                    node.closest(".chat-item") ||
                    node.closest("[data-message-id]") ||
                    node.closest("[data-msg-id]") ||
                    node.parentElement;

                const text = clean(
                    node.innerText || node.textContent
                );

                const senderNode = root?.querySelector(
                    ".message-sender-name-wrapper, " +
                    ".sender-name, .message-sender, .user-name"
                );

                const sender = clean(
                    senderNode?.innerText ||
                    senderNode?.textContent
                );

                const id =
                    root?.id ||
                    root?.getAttribute("data-id") ||
                    root?.getAttribute("data-message-id") ||
                    root?.getAttribute("data-msg-id") ||
                    "";

                const classText = clean(
                    [
                        root?.className,
                        root?.getAttribute("data-is-me"),
                        root?.getAttribute("data-from-me"),
                        root?.getAttribute("data-direction")
                    ].join(" ")
                ).toLowerCase();

                const outgoingByClass =
                    /from-me|is-me|message-me|msg-me|self-message|outgoing/i
                        .test(classText);

                return {
                    key: (
                        id ||
                        [
                            index,
                            sender,
                            text,
                            root?.getAttribute("data-time") || ""
                        ].join("|")
                    ),
                    text,
                    sender,
                    outgoing_by_class: Boolean(outgoingByClass)
                };
            }).filter(item => item.text);
        }
        """
    )

    for message in messages:
        message["is_outgoing"] = bool(
            message.get("outgoing_by_class", False)
            or is_recent_sent_message(
                message.get("text", "")
            )
        )

    return messages

def send_message(page, content: str) -> None:
    box = find_input_box(page)
    if box is None:
        raise RuntimeError("Không tìm thấy ô nhập Zalo.")

    box.click()

    try:
        box.fill("")
    except Exception:
        page.keyboard.press("Control+A")
        page.keyboard.press("Backspace")

    page.keyboard.insert_text(content)
    time.sleep(0.3)
    page.keyboard.press("Enter")
    remember_sent_message(content)
    time.sleep(0.6)


def send_message_with_mention(
    page,
    mention_name: str,
    content: str,
) -> None:
    """
    Tag đúng người trong popup gợi ý mention của Zalo.

    Luồng:
    1. Đóng popup hồ sơ nếu có.
    2. Focus ô nhập.
    3. Gõ @Hậu.
    4. Chờ popup gợi ý hiện.
    5. ArrowDown + Enter để chọn đúng mention.
    6. Nhập nội dung và gửi.

    Không click tên trên toàn trang.
    """

    # Đóng popup hồ sơ hoặc menu đang mở.
    for _ in range(2):
        page.keyboard.press("Escape")
        time.sleep(0.15)

    box = find_input_box(page)

    if box is None:
        raise RuntimeError("Không tìm thấy ô nhập Zalo.")

    box.click()

    try:
        box.fill("")
    except Exception:
        page.keyboard.press("Control+A")
        page.keyboard.press("Backspace")

    # Theo giao diện thực tế: chỉ cần gõ @Hậu là popup hiện đúng người.
    first_name = (
        mention_name.split()[0]
        if mention_name.strip()
        else "Hậu"
    )

    page.keyboard.insert_text("@" + first_name)
    time.sleep(0.9)

    # Chọn kết quả đầu tiên trong popup mention.
    page.keyboard.press("ArrowDown")
    time.sleep(0.2)
    page.keyboard.press("Enter")
    time.sleep(0.35)

    # Nhập nội dung sau mention.
    page.keyboard.insert_text("\n" + content)
    time.sleep(0.35)

    # Gửi.
    page.keyboard.press("Enter")
    remember_sent_message(content)
    time.sleep(0.8)

