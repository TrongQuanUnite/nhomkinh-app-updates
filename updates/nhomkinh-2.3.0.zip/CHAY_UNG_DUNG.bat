@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title Nhom Kinh + Zalo — 1 ung dung
set "NKPY="
py -3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
if not errorlevel 1 set "NKPY=py -3"
if defined NKPY goto found
python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
if not errorlevel 1 set "NKPY=python"
if defined NKPY goto found
echo Khong tim thay Python 3.10 tro len.
echo Thu mo CMD va go: py --version
echo Neu chua co, cai Python tu https://www.python.org/downloads/windows/
pause
exit /b 1
:found
if exist .venv\Scripts\python.exe goto install
%NKPY% -m venv .venv
if errorlevel 1 goto failed
:install
.venv\Scripts\python.exe bootstrap.py
if errorlevel 1 goto failed
:run
if /i "%~1"=="google" goto google
.venv\Scripts\python.exe launcher.py
goto end
:google
.venv\Scripts\python.exe google_login.py
goto end
:failed
echo Cai dat that bai. Chup cua so nay de kiem tra loi.
:end
pause
