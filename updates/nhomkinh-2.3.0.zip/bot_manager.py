"""One app owns the Zalo subprocess and browser lifecycle."""
import json,os,signal,subprocess,sys,threading,time
from store import BASE,save_json
class BotManager:
    def __init__(self):
        self.process=None;self.thread=None;self.stopping=threading.Event();self.lock=threading.RLock();self.last_error='';self.manual_stop=False;self.restart_requested=False
    def start_supervisor(self):
        if self.thread and self.thread.is_alive():return
        self.stopping.clear();self.thread=threading.Thread(target=self._loop,daemon=True);self.thread.start()
    def _launch(self):
        (BASE/'.zalo_stop').unlink(missing_ok=True)
        (BASE/'zalo_runtime.json').unlink(missing_ok=True)
        log=open(BASE/'zalo_bot.log','a',encoding='utf8')
        env=os.environ.copy();env['NK_BOT_OWNER_PID']=str(os.getpid())
        kw={'cwd':BASE,'stdout':log,'stderr':subprocess.STDOUT,'env':env}
        if os.name=='nt':kw['creationflags']=subprocess.CREATE_NO_WINDOW|subprocess.CREATE_NEW_PROCESS_GROUP
        else:kw['start_new_session']=True
        try:
            self.process=subprocess.Popen([sys.executable,str(BASE/'zalo_runner.py'),'--managed'],**kw)
            save_json(BASE/'zalo_process.json',{'pid':self.process.pid,'session':os.environ.get('NK_APP_SESSION','')})
        finally:log.close()
    def _stop_process(self):
        proc=self.process
        if proc is None:return
        (BASE/'.zalo_stop').write_text('stop')
        try:proc.wait(timeout=8)
        except subprocess.TimeoutExpired:
            if os.name=='nt':subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            else:
                try:os.killpg(proc.pid,signal.SIGTERM)
                except ProcessLookupError:pass
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                if os.name!='nt':
                    try:os.killpg(proc.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
        self.process=None
        (BASE/'zalo_process.json').unlink(missing_ok=True)
    def _loop(self):
        from zalo_integration import settings
        while not self.stopping.is_set():
            try:
                with self.lock:
                    if self.restart_requested:
                        self._stop_process();self.restart_requested=False;self.manual_stop=False
                    wanted=settings()['enabled'] and not self.manual_stop
                    if self.process is not None and self.process.poll() is not None:
                        self.last_error='Bot đã dừng. Xem trạng thái bên dưới hoặc bấm Khởi động lại.';self.process=None;self.manual_stop=True
                    if wanted and self.process is None and not self.manual_stop:self._launch()
                    elif not wanted and self.process is not None:self._stop_process()
            except Exception:self.last_error='Chưa khởi động được bot Zalo. Kiểm tra môi trường Python.';self.manual_stop=True
            self.stopping.wait(1)
        with self.lock:self._stop_process()
    def resume(self):
        with self.lock:
            self.manual_stop=False;self.last_error=''
            if self.process is not None:self.restart_requested=True
        if self.restart_requested:(BASE/'.zalo_stop').write_text('restart')
    def pause(self):
        with self.lock:self.manual_stop=True
        (BASE/'.zalo_stop').write_text('stop')
    def snapshot(self):
        p=BASE/'zalo_runtime.json'
        try:runtime=json.loads(p.read_text('utf8')) if p.exists() else {}
        except Exception:runtime={}
        with self.lock:running=self.process is not None and self.process.poll() is None
        if runtime.get('heartbeat') and time.time()-runtime['heartbeat']>90:runtime['state']='stale'
        return {'running':running,'paused':self.manual_stop,'error':self.last_error,'runtime':runtime}
    def close(self):
        self.stopping.set()
        if self.thread:self.thread.join(timeout=16)
        with self.lock:self._stop_process()
manager=BotManager()
