from pathlib import Path
from google_auth_oauthlib.flow import InstalledAppFlow
base=Path(__file__).resolve().parent
if not (base/'oauth_client.json').exists():
    print('Chua co oauth_client.json. Doc HUONG_DAN.txt, phan Gmail ca nhan.');input('Enter de dong');raise SystemExit(1)
flow=InstalledAppFlow.from_client_secrets_file(str(base/'oauth_client.json'),['https://www.googleapis.com/auth/spreadsheets','https://www.googleapis.com/auth/drive'])
creds=flow.run_local_server(port=0,access_type='offline',prompt='consent')
(base/'google_token.json').write_text(creds.to_json(),'utf8')
print('Da ket noi Google. Quay lai app, chon che do Google va Kiem tra.');input('Enter de dong')
