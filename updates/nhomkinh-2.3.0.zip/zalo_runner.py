"""Managed by the app. No separate launch/login console required."""
import hashlib,json,subprocess,sys,time,os
from pathlib import Path
import requests
from playwright.sync_api import sync_playwright
from store import BASE,save_json
from zalo_integration import settings,token
from zalo_transport import find_input_box,switch_to_group,read_visible_messages,send_message
from location_scanner import scan_location_pairs,normalize_map_url
URL='http://127.0.0.1:8000/api/zalo'
MANAGED='--managed' in sys.argv

def emit(state,message):
    save_json(BASE/'zalo_runtime.json',{'state':state,'message':message,'heartbeat':time.time()})
def stopped():
    from process_utils import alive
    return (BASE/'.zalo_stop').exists() or not settings()['enabled'] or not alive(os.environ.get('NK_BOT_OWNER_PID'))
def key(msg,group):
    raw=msg['key'] if msg.get('key') and '|' not in msg['key'] else msg.get('sender','')+'|'+msg['text']
    return hashlib.sha256((group+'|'+raw).encode()).hexdigest()
def pair_data(pair,group):
    label=str(pair.get('label','')).strip();link=next((u for u in (normalize_map_url(x) for x in pair.get('candidates',[]) if isinstance(x,str)) if u),'')
    if not label or not link:return None
    sender=str(pair.get('sender','')).strip();mid=hashlib.sha256((group+'|'+sender+'|'+label+'|'+link).encode()).hexdigest()
    return {'group':group,'sender':sender,'label':label,'url':link,'message_id':mid}
def api(path,data=None):
    r=requests.post(URL+path,headers={'Authorization':'Bearer '+token(),'X-App-Request':'1'},json=data or {},timeout=(5,65));r.raise_for_status();return r.json()
def run():
    cfg=settings()
    if not cfg['enabled']:emit('stopped','Bot đang tắt.');return
    state=BASE/'zalo_seen.json';seen=set(json.loads(state.read_text('utf8'))) if state.exists() else set()
    location_seen=set();baselined_location=False
    def save_seen():save_json(state,sorted(seen)[-10000:])
    emit('starting','Đang khởi động Zalo…')
    with sync_playwright() as p:
        if not Path(p.chromium.executable_path).exists():
            emit('installing_browser','Lần đầu: đang tải trình duyệt Zalo, giữ app mở và kết nối Internet.')
            # A child shares the runner process group, so the app can stop the whole installation tree.
            install=subprocess.Popen([sys.executable,'-m','playwright','install','chromium'],cwd=BASE)
            while install.poll() is None:
                if stopped():install.terminate();install.wait();emit('stopped','Đã dừng cài trình duyệt.');return
                emit('installing_browser','Đang tải/cài trình duyệt Zalo lần đầu…');time.sleep(3)
            if install.returncode:emit('error','Chưa tải được trình duyệt Zalo. Kiểm tra Internet rồi bấm Khởi động lại bot.');return
        if stopped():emit('stopped','Bot đã tắt.');return
        context=p.chromium.launch_persistent_context(str(BASE/'zalo_profile'),headless=False,viewport={'width':1440,'height':900})
        try:
            page=context.pages[0] if context.pages else context.new_page();page.goto('https://chat.zalo.me/',wait_until='domcontentloaded',timeout=60000)
            while find_input_box(page) is None:
                if stopped():return
                emit('waiting_login','Quét QR bằng tài khoản Zalo của bot trong cửa sổ vừa mở.');time.sleep(1)
            emit('selecting_group','Đang mở nhóm công việc đã cấu hình…')
            while not switch_to_group(page,cfg['group_name']):
                if stopped():return
                emit('selecting_group','Không thấy nhóm. Kiểm tra tên nhóm, bot phải tham gia nhóm và tên nhóm phải duy nhất.');time.sleep(3)
            for msg in read_visible_messages(page):seen.add(key(msg,cfg['group_name']))
            save_seen();last_location=0;last_reminder=0
            while not stopped():
                latest=settings()
                if latest['group_name']!=cfg['group_name']:
                    emit('restart_required','Tên nhóm công việc đã đổi. Bấm Khởi động lại bot.');return
                if not switch_to_group(page,cfg['group_name']):
                    emit('selecting_group','Chưa mở được nhóm công việc.');time.sleep(3);continue
                emit('running','Bot đang chạy chung với app — nghe @'+latest['mention'])
                for msg in read_visible_messages(page):
                    if stopped():break
                    mid=key(msg,cfg['group_name'])
                    if mid in seen or msg.get('is_outgoing'):continue
                    try:
                        result=api('/bridge',{'group':cfg['group_name'],'sender':msg.get('sender',''),'message_id':mid,'text':msg['text']})
                        # Do not send unless currently inside the exact configured group.
                        if result.get('reply'):send_message(page,result['reply'])
                        seen.add(mid);save_seen()
                    except requests.RequestException:emit('connection_error','Chưa kết nối được dữ liệu web/Google. Bot sẽ thử lại.')
                now=time.monotonic()
                if latest['location_enabled'] and latest['location_group_name'] and now-last_location>=60 and not stopped():
                    if switch_to_group(page,latest['location_group_name']):
                        pairs=[v for v in (pair_data(pair,latest['location_group_name']) for pair in scan_location_pairs(page)) if v]
                        if not baselined_location:
                            location_seen.update(v['message_id'] for v in pairs);baselined_location=True
                        else:
                            for item in pairs:
                                if item['message_id'] in location_seen or 'loc:'+item['message_id'] in seen:continue
                                try:
                                    api('/location',item);location_seen.add(item['message_id']);seen.add('loc:'+item['message_id']);save_seen()
                                except requests.RequestException:emit('connection_error','Chưa ghi được định vị. Sẽ thử lại.')
                    switch_to_group(page,cfg['group_name']);last_location=now
                if latest['reminders_enabled'] and now-last_reminder>=30 and not stopped():
                    try:
                        reminders=api('/reminders')
                        if reminders and switch_to_group(page,cfg['group_name']):
                            for reminder in reminders:
                                if reminder['group']!=cfg['group_name'] or stopped():continue
                                send_message(page,reminder['text']);api('/reminders/'+reminder['id']+'/sent')
                    except requests.RequestException:emit('connection_error','Chưa kiểm tra/ghi nhận nhắc lịch. Kiểm tra Google và mạng.')
                    last_reminder=now
                time.sleep(2)
        finally:
            context.close()
            if stopped():emit('stopped','Bot đã dừng cùng app.')
if __name__=='__main__':
    try:run()
    except KeyboardInterrupt:emit('stopped','Bot đã dừng.')
    except Exception as e:
        emit('error','Lỗi Zalo '+type(e).__name__+'. Đóng cửa sổ Zalo khác rồi Khởi động lại bot; nếu còn lỗi, kiểm tra zalo_bot.log.')
        print('Zalo runtime error type:',type(e).__name__)
    if not MANAGED:input('Enter để đóng...')
