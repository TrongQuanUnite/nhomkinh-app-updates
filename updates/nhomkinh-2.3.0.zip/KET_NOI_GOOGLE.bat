@echo off
cd /d "%~dp0"
call CHAY_UNG_DUNG.bat google
