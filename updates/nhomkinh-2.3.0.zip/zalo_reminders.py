import datetime,hashlib,json
from store import BASE,LOCK,store,save_json,norm
TZ=datetime.timezone(datetime.timedelta(hours=7))
def sent():
    p=BASE/'zalo_reminders.json'
    return json.loads(p.read_text('utf8')) if p.exists() else []
def due(now=None):
    from zalo_integration import settings
    cfg=settings()
    if not cfg['enabled'] or not cfg['reminders_enabled']:return []
    now=now or datetime.datetime.now(TZ);sent_ids=set(sent());out=[]
    with LOCK:
        for p in store.rows():
            if 'hoanthanh' in norm(p['trang_thai']):continue
            for field,title in [('lap_lay_ngay','Lắp lấy ngày'),('lich_lap_dat','Lắp đặt')]:
                value=p.get(field,'').strip()
                try:dt=datetime.datetime.strptime(value,'%d/%m/%Y %H:%M').replace(tzinfo=TZ)
                except ValueError:continue
                remind_at=dt-datetime.timedelta(hours=18)
                key=hashlib.sha256((p['ten_cong_trinh']+'|'+field+'|'+value).encode()).hexdigest()
                if remind_at<=now<dt and now-remind_at<=datetime.timedelta(hours=3) and key not in sent_ids:
                    recipient=cfg['reminder_recipient']
                    text='NHẮC LỊCH '+title.upper()+'\n'+p['ten_cong_trinh']+'\nThời gian: '+value+'\nĐội: '+p['doi_truong']
                    if recipient:text+='\nNgười nhận: '+recipient
                    out.append({'id':key,'text':text,'group':cfg['group_name'],'recipient':recipient})
    return out
def acknowledge(key):
    if not any(e['id']==key for e in due()):raise ValueError('Lịch nhắc không còn trong danh sách đến hạn.')
    with LOCK:
        data=sent()
        if key not in data:data.append(key);save_json(BASE/'zalo_reminders.json',data[-5000:])
