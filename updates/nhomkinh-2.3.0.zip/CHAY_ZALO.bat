@echo off
cd /d "%~dp0"
echo Zalo da gop vao ung dung chinh. Chi can chay CHAY_UNG_DUNG.bat.
call CHAY_UNG_DUNG.bat
