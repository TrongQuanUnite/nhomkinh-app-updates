"""Workflow schema; stages have distinct values and permissions."""
PLAN=[('ten_cong_trinh','Tên công trình'),('thau','Thầu'),('nguoi_do','Người đo'),('do_dac','Đo đạc'),('lap_lay_ngay','Lắp lấy ngày'),('trang_thai','Trạng thái tổng')]
PRODUCTION=[('sx_cua_nhua','Cửa nhựa'),('sx_cua_so','Cửa sổ'),('sx_cua_di','Cửa đi'),('sx_vom','Vòm'),('sx_kinh_cua','Kính cửa'),('sx_kinh_vom','Kính vòm'),('sx_khung_bao_ve','Khung bảo vệ'),('sx_lan_can','Lan can'),('sx_cau_thang','Cầu thang'),('sx_bep','Bếp')]
INSTALLATION=[('ld_cua_nhua','Cửa nhựa'),('ld_cua','Cửa'),('ld_khung_bao_ve','Khung bảo vệ'),('ld_lan_can','Lan can'),('ld_cau_thang','Cầu thang'),('ld_bep','Bếp'),('ve_sinh','Vệ sinh'),('giao_chia_khoa','Giao chìa khóa')]
WORKFLOW=PLAN+PRODUCTION+INSTALLATION+[('dinh_vi','Định vị')]
NOTE_FIELDS=[k+'_ghi_chu' for k,_ in WORKFLOW]

OVERALL_STATUSES=["Đang Thực Hiện","Hoàn Thành"]
def overall_status(value,strict=False):
    text=str(value).strip().casefold()
    if text=="hoàn thành":return OVERALL_STATUSES[1]
    if strict and text not in {"","đang thực hiện"}:raise ValueError("Trạng thái không hợp lệ")
    return OVERALL_STATUSES[0]

GLASS=[('sx_kinh_vom','Kính vòm'),('sx_kinh_cua','Kính cửa')]
GLASS_COUNTS=[('kinh_vom_da_nhan','Số tấm kính vòm đã nhận'),('kinh_cua_da_nhan','Số tấm kính cửa đã nhận')]
GLASS_STATUSES=['Chưa Đặt','Đã Đặt','Đã Nhận']
def validate_glass(data,current=None):
    current=current or {}
    for (status,_),(count,_) in zip(GLASS,GLASS_COUNTS):
        if status in data and data[status] not in GLASS_STATUSES+['']:
            raise ValueError('Trạng thái kính chỉ có Chưa Đặt, Đã Đặt, Đã Nhận.')
        if count in data and data[count]!='':
            if not data[count].isascii() or not data[count].isdigit():raise ValueError('Số tấm kính đã nhận phải là số nguyên không âm.')
            data[count]=str(int(data[count]))
        if (status in data or count in data) and data.get(status,current.get(status))=='Đã Nhận':
            value=data.get(count,current.get(count,''))
            if not str(value).isascii() or not str(value).isdigit() or int(value)<1:raise ValueError('Chọn Đã Nhận cần nhập số tấm kính đã nhận lớn hơn 0.')
