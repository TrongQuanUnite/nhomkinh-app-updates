import re
from urllib.parse import urlparse,parse_qs

def normalize_map_url(value):
    value=str(value or '').strip()
    try:
        parsed=urlparse(value)
        if parsed.scheme!='https' or parsed.hostname not in {'www.google.com','google.com','maps.google.com','maps.app.goo.gl','goo.gl'}:return ''
        if parsed.hostname in {'www.google.com','google.com'} and not parsed.path.startswith('/maps'):return ''
        if parsed.hostname=='goo.gl' and not parsed.path.startswith('/maps'):return ''
        q=parse_qs(parsed.query)
        for key in ['ll','q']:
            raw=q.get(key,[''])[0]
            if re.fullmatch(r'-?\d+(?:\.\d+)?\s*,\s*-?\d+(?:\.\d+)?',raw):
                lat,lng=map(float,raw.split(','))
                if not (-90<=lat<=90 and -180<=lng<=180):return ''
                return 'https://www.google.com/maps?q='+re.sub(r'\s+','',raw)
        # Google embeds encode longitude/latitude in pb rather than q/ll.
        pb=q.get('pb',[''])[0]
        match=re.search(r'!3d(-?\d+(?:\.\d+)?)!4d(-?\d+(?:\.\d+)?)',pb)
        if match:lat,lng=map(float,match.groups())
        else:
            match=re.search(r'!2d(-?\d+(?:\.\d+)?)!3d(-?\d+(?:\.\d+)?)',pb)
            if match:lng,lat=map(float,match.groups())
        if match:
            if -90<=lat<=90 and -180<=lng<=180:return f'https://www.google.com/maps?q={lat},{lng}'
            return ''
        if q.get('output',[''])[0]=='embed' or '/embed' in parsed.path:return '' 
        return value
    except Exception:return ''

def scan_location_pairs(page) -> list[dict]:
    return page.evaluate(
        r"""
        () => {
            const clean = value =>
                String(value || "")
                    .replace(/\u200B/g, "")
                    .replace(/\s+/g, " ")
                    .trim();

            const cards = Array.from(
                document.querySelectorAll(
                    ".location-message__info-container, " +
                    ".location-message-info-container, iframe[src*='google'][src*='maps']"
                )
            );

            const textNodes = Array.from(
                document.querySelectorAll(
                    ".text-message__container .text, " +
                    ".text-message_container .text"
                )
            );

            const pairs = [];

            for (const card of cards) {
                const root =
                    card.closest(".chat-message") ||
                    card.closest(".chat-item") ||
                    card.parentElement;

                const hrefs = Array.from(
                    root.querySelectorAll("a[href], iframe[src]")
                ).map(node => node.href || node.src || "");

                const attrs = [];

                for (const node of root.querySelectorAll("*")) {
                    for (const attr of node.attributes || []) {
                        if (
                            /href|src|url|map|location|onclick|data/i
                            .test(attr.name + " " + attr.value)
                        ) {
                            attrs.push(attr.value);
                        }
                    }
                }

                let label = "";
                let labelSender = "";
                const senderOf = node => {
                    const message=node.closest('.chat-message') || node.closest('.chat-item') || node.parentElement;
                    const name=message?.querySelector('.message-sender-name-wrapper, .sender-name, .message-sender, .user-name');
                    return clean(name?.innerText || name?.textContent);
                };
                const cardSender=senderOf(card);
                const cardRect = card.getBoundingClientRect();
                let bestDistance = Infinity;

                for (const textNode of textNodes) {
                    const text = clean(
                        textNode.innerText ||
                        textNode.textContent
                    );

                    const textSender=senderOf(textNode);
                    if (cardSender && textSender && cardSender!==textSender) continue;
                    if (!text || /Tin nhắn đã được thu hồi/i.test(text)) {
                        continue;
                    }

                    const rect = textNode.getBoundingClientRect();

                    if (rect.top >= cardRect.bottom - 5) {
                        const distance = rect.top - cardRect.bottom;

                        if (distance < bestDistance && distance < 180) {
                            label = text;
                            labelSender = textSender;
                            bestDistance = distance;
                        }
                    }
                }

                const senderNode = root.querySelector(
                    ".message-sender-name-wrapper, " +
                    ".sender-name, .message-sender, .user-name"
                );

                const sender = clean(
                    senderNode?.innerText ||
                    senderNode?.textContent
                );

                pairs.push({
                    label,
                    sender: sender || labelSender,
                    text: clean(
                        root.innerText || root.textContent
                    ),
                    candidates: [card.src || "", ...hrefs, ...attrs]
                });
            }

            const seen=new Set();
            return pairs.filter(pair => {
                const k=JSON.stringify([pair.label,pair.sender,pair.candidates]);
                if(seen.has(k))return false;seen.add(k);return true;
            });
        }
        """
    )
