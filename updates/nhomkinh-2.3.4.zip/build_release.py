"""Maintainer: python build_release.py OWNER/REPO — output contains NO user files."""
import hashlib,json,sys,zipfile
from pathlib import Path
from updater import FILES,VERSION,APP_ID
base=Path(__file__).resolve().parent
repo=sys.argv[1] if len(sys.argv)>1 else 'TrongQuanUnite/nhomkinh-app-updates'
out=base/'updates';out.mkdir(exist_ok=True)
name='nhomkinh-'+VERSION+'.zip';archive=out/name
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in FILES:z.write(base/f,f)
manifest={'app_id':APP_ID,'version':VERSION,'min_python':'3.10.0','url':f'https://raw.githubusercontent.com/{repo}/main/updates/{name}','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'notes':'Đọc thẻ Google Maps iframe và tọa độ pb nhúng; hiển thị số thẻ/cặp định vị quét được và lỗi mở nhóm.'}
(out/'release.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),'utf8')
print('Upload updates/'+name+' và updates/release.json lên nhánh main. Không upload khóa/token hoặc dữ liệu cá nhân.')
