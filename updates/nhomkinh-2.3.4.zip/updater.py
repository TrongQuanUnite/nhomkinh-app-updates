"""Updates only packaged application files; never copies user data or credentials."""
import hashlib, json, re, shutil, subprocess, sys, tempfile, zipfile, secrets
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse
import requests
from store import BASE, save_json
VERSION='2.3.4'
APP_ID='nhomkinh-app'
FILES=['main.py','store.py','updater.py','launcher.py','google_login.py','requirements.txt','CHAY_UNG_DUNG.bat','KET_NOI_GOOGLE.bat','HUONG_DAN.txt','templates/index.html','VERSION.txt','build_release.py','preferences.py','zalo_integration.py','zalo_runner.py','zalo_transport.py','CHAY_ZALO.bat','zalo_ai.py','bot_manager.py','bootstrap.py','location_scanner.py','zalo_reminders.py','process_utils.py','easy_setup.py']
MAX_ZIP=20*1024*1024

def semver(v):
    if not re.fullmatch(r'\d+\.\d+\.\d+',v):raise ValueError('Phiên bản phải có dạng 2.1.0.')
    return tuple(map(int,v.split('.')))
def safe_files(names):
    required={'main.py','store.py','updater.py','launcher.py','requirements.txt','VERSION.txt'}
    if len(names)!=len(set(n.casefold() for n in names)) or not required<=set(names):raise ValueError('Gói cập nhật thiếu file ứng dụng bắt buộc.')
    for name in names:
        path=PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or '\\' in name:raise ValueError('Đường dẫn không hợp lệ.')
        root_file=len(path.parts)==1 and (bool(re.fullmatch(r'[A-Za-z0-9_-]+\.(?:py|bat)',name)) or name in {'requirements.txt','HUONG_DAN.txt','VERSION.txt'})
        template=len(path.parts)==2 and path.parts[0]=='templates' and bool(re.fullmatch(r'[A-Za-z0-9_-]+\.(?:html|css|js)',path.name))
        if not (root_file or template):raise ValueError('Gói chứa file ngoài mã nguồn app: '+name)
    return names

def settings():
    p=BASE/'update_settings.json'
    return json.loads(p.read_text('utf8')) if p.exists() else {'repository':'TrongQuanUnite/nhomkinh-app-updates','channel_path':'updates'}
def set_repository(repository):
    repository=repository.strip().removeprefix('https://github.com/').removesuffix('/').removesuffix('.git')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',repository):raise ValueError('Nhập repository dạng TrongQuanUnite/nhomkinh-app-updates.')
    save_json(BASE/'update_settings.json',{'repository':repository,'channel_path':'updates'})
def download(url,limit):
    parsed=urlparse(url)
    if parsed.scheme!='https' or parsed.hostname not in {'raw.githubusercontent.com','github.com'}:raise ValueError('Chỉ nhận bản phát hành HTTPS từ GitHub đã cấu hình.')
    with requests.get(url,timeout=(10,60),stream=True) as r:
        r.raise_for_status();out=bytearray()
        for chunk in r.iter_content(65536):
            out.extend(chunk)
            if len(out)>limit:raise ValueError('Bản cập nhật vượt giới hạn dung lượng.')
        return bytes(out)
def check():
    s=settings()
    if not s['repository']:return {'current':VERSION,'configured':False,'available':False}
    repo=s['repository'];path=s['channel_path'];url=f'https://raw.githubusercontent.com/{repo}/main/{path}/release.json'
    try:m=json.loads(download(url,65536))
    except requests.RequestException:raise ValueError('Chưa đọc được bản phát hành GitHub. Kiểm tra repository public, mạng và updates/release.json.')
    if m.get('app_id')!=APP_ID:raise ValueError('Bản phát hành không thuộc app Nhôm Kính.')
    semver(m.get('version',''))
    if not re.fullmatch('[0-9a-f]{64}',m.get('sha256','')):raise ValueError('Bản phát hành thiếu SHA-256 hợp lệ.')
    expected_prefix=f'https://raw.githubusercontent.com/{repo}/main/{path}/'
    if not m.get('url','').startswith(expected_prefix):raise ValueError('Link gói cập nhật không thuộc repository đã cấu hình.')
    if semver(m.get('min_python','3.10.0'))>sys.version_info[:3]:raise ValueError('Bản mới cần Python '+m['min_python']+'.')
    return {'current':VERSION,'configured':True,'available':semver(m['version'])>semver(VERSION),'release':m}
def stage(m):
    data=download(m['url'],MAX_ZIP)
    if hashlib.sha256(data).hexdigest()!=m['sha256']:raise ValueError('Checksum không khớp; app giữ nguyên bản hiện tại.')
    root=BASE/'.updates';root.mkdir(exist_ok=True)
    folder=Path(tempfile.mkdtemp(prefix='staged-',dir=root));archive=folder/'package.zip';archive.write_bytes(data)
    try:
        with zipfile.ZipFile(archive) as z:
            names=z.namelist()
            safe_files(names)
            if sum(i.file_size for i in z.infolist())>MAX_ZIP:raise ValueError('Gói giải nén quá lớn.')
            for info in z.infolist():
                p=PurePosixPath(info.filename)
                if p.is_absolute() or '..' in p.parts or (info.external_attr>>16)&0o170000==0o120000:raise ValueError('Đường dẫn trong gói không hợp lệ.')
                dest=folder/info.filename;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(info))
        if (folder/'VERSION.txt').read_text().strip()!=m['version']:raise ValueError('Phiên bản trong ZIP không khớp bản phát hành.')
        for file in folder.rglob('*.py'):compile(file.read_text('utf8'),str(file),'exec')
        job_id=secrets.token_hex(12)
        save_json(root/'pending.json',{'folder':str(folder.resolve()),'version':m['version'],'job_id':job_id,'files':names})
        return job_id
    except Exception:
        shutil.rmtree(folder,ignore_errors=True);raise

def apply_pending():
    root=BASE/'.updates';pending=root/'pending.json'
    if not pending.exists():return False
    job=json.loads(pending.read_text('utf8'));folder=Path(job['folder']).resolve()
    if folder.parent!=root.resolve() or not folder.name.startswith('staged-'):raise ValueError('Thư mục cập nhật không hợp lệ.')
    files=safe_files(job.get('files',FILES))
    backup=Path(tempfile.mkdtemp(prefix='backup-',dir=root));existing=set()
    for name in files:
        src=BASE/name
        if src.exists():
            existing.add(name);dest=backup/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
    def restore():
        for name in files:
            dest=BASE/name
            if name in existing:shutil.copy2(backup/name,dest)
            else:dest.unlink(missing_ok=True)
    try:
        if (folder/'requirements.txt').read_bytes()!=(BASE/'requirements.txt').read_bytes():
            result=subprocess.run([sys.executable,'-m','pip','install','-r',str(folder/'requirements.txt')],cwd=BASE)
            if result.returncode:raise ValueError('Không cài được thư viện bản mới.')
        for name in files:
            dest=BASE/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(folder/name,dest)
        probe=subprocess.run([sys.executable,'-c','import main; import updater; assert updater.VERSION == '+repr(job['version'])],cwd=BASE,capture_output=True,timeout=45)
        if probe.returncode:raise ValueError('Bản mới không khởi động được; khôi phục bản cũ.')
        save_json(root/'result.json',{'ok':True,'job_id':job['job_id'],'message':'Đã cập nhật lên '+job['version']})
    except Exception as e:
        restore()
        if (backup/'requirements.txt').exists():subprocess.run([sys.executable,'-m','pip','install','-r',str(backup/'requirements.txt')],cwd=BASE)
        save_json(root/'result.json',{'ok':False,'job_id':job['job_id'],'message':str(e)+' Đã giữ lại mã nguồn bản trước; xem cửa sổ chạy nếu thư viện chưa khôi phục được.'})
    finally:
        pending.unlink(missing_ok=True);shutil.rmtree(folder,ignore_errors=True)
    return True
