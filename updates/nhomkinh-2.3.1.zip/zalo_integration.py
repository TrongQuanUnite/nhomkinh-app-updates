"""Backend for a local Zalo Web bridge. No live messages sent by the build."""
import datetime,json,re,secrets,hashlib
from store import BASE,LOCK,store,norm,save_json,FIELDS,LABELS
DEFAULT={'enabled':False,'group_name':'','mention':'AI','auto_apply':False,'senders':{},'location_enabled':False,'location_group_name':'','reminders_enabled':False,'reminder_recipient':''}
def settings():
    p=BASE/'zalo_settings.json'
    data=json.loads(p.read_text('utf8')) if p.exists() else {}
    return {k:data.get(k,v) for k,v in DEFAULT.items()}
def token():
    p=BASE/'.zalo_bridge_token'
    if not p.exists():p.write_text(secrets.token_hex(32))
    return p.read_text().strip()
def queue():
    p=BASE/'zalo_events.json'
    return json.loads(p.read_text('utf8')) if p.exists() else []
def save_events(events):save_json(BASE/'zalo_events.json',events[-1000:])
def authorized_rows(u):
    from main import target
    rows=[]
    for p in store.rows():
        try:target(p['row_index'],u);rows.append(p)
        except Exception:continue
    return rows

def parse(text,rows):
    n=norm(text)
    query=bool('?' in text or any(norm(x) in n for x in ['thế nào','ra sao','xong chưa','đã xong chưa','cho xem','tiến độ tới đâu','tình hình','đã có kính chưa','định vị','địa chỉ','vị trí']))
    list_query=any(norm(x) in n for x in ['danh sách','liệt kê','công trình nào'])
    candidates=[p for p in rows if norm(p['ten_cong_trinh']) and norm(p['ten_cong_trinh']) in n]
    # Explicit "công trình: NAME; ..." also accepts a UNIQUE shortened name.
    match=re.search(r'(?:công trình|nhà)\s*:\s*([^;\n]+)',text,re.I)
    if match:
        name=norm(match.group(1));candidates=[p for p in rows if name and name in norm(p['ten_cong_trinh'])]
    if query or list_query:return {'kind':'query','candidates':candidates,'list':list_query}
    data={}
    for k,label in zip(FIELDS,LABELS):
        if k in ['hinh_anh','ten_cong_trinh','thoi_gian','tien_do_bao_cao']:continue
        m=re.search(re.escape(label)+r'\s*:\s*([^;\n]+)',text,re.I)
        if m:data[k]=m.group(1).strip()
    # Unstructured updates are kept as a report instead of guessing status fields.
    data['tien_do_bao_cao']=text.strip()
    return {'kind':'update','candidates':candidates,'data':data}
def apply(event,project_id,u):
    from main import target
    p=target(project_id,u,event.get('version') if event.get('project_id')==project_id else None)
    data=event['data'].copy()
    if data.get('dinh_vi'):
        from location_scanner import normalize_map_url
        data['dinh_vi']=normalize_map_url(data['dinh_vi'])
        if not data['dinh_vi']:raise ValueError('Link định vị không hợp lệ.')
    allowed=set(FIELDS)-{'hinh_anh','ten_cong_trinh','thoi_gian'} if u['role']=='chu' else {'tien_do_bao_cao','ve_sinh','giao_chia_khoa','trang_thai','thieu_hang_muc','dinh_vi'}
    if not set(data)<=allowed:raise ValueError('Tài khoản thợ không được sửa thông tin vật tư/phân công; chủ cần duyệt báo cáo này.')
    now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=7))).strftime('%d/%m/%Y %H:%M')
    note=f"[{now} · Zalo · {event['sender']}] {data.pop('tien_do_bao_cao','')}"
    data['tien_do_bao_cao']=(p['tien_do_bao_cao']+'\n'+note).strip();store.update(project_id,data)
    event.update(status='applied',project_id=project_id)
    return 'Đã cập nhật '+p['ten_cong_trinh']+'.'
def receive(payload):
    from main import users,public
    cfg=settings()
    if not cfg['enabled'] or payload.get('group')!=cfg['group_name']:return {'reply':'','status':'ignored'}
    text=str(payload.get('text',''));sender=str(payload.get('sender','')).strip();message_id=str(payload.get('message_id',''))
    if not message_id or len(message_id)>300 or len(text)>15000:raise ValueError('Tin nhắn không hợp lệ.')
    mention='@'+cfg['mention']
    if not re.search(re.escape(mention)+r'(?!\w)',text,re.I):return {'reply':'','status':'ignored'}
    db=users();account=cfg['senders'].get(sender);u=db.get(account)
    if not u:
        # Collect the raw report for owner review; no project access or AI call.
        with LOCK:
            events=queue();key=hashlib.sha256((payload['group']+'|'+message_id).encode()).hexdigest()
            if any(e['id']==key for e in events):return {'reply':'','status':'duplicate'}
            events.append({'id':key,'sender':sender,'username':'','text':text,'group':payload['group'],'received_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'unverified','status':'pending','data':{'tien_do_bao_cao':text},'unverified':True})
            save_events(events)
        return {'reply':'','status':'pending'}
    clean=re.sub(re.escape(mention)+r'(?!\w)','',text,flags=re.I).strip()
    with LOCK:
        events=queue();key=hashlib.sha256((payload['group']+'|'+message_id).encode()).hexdigest()
        if any(e['id']==key for e in events):return {'reply':'','status':'duplicate'}
        choice=re.fullmatch(r'(?:chọn|chon|số|so)\s*(\d+)',clean,re.I)
        if choice:
            pending=next((e for e in reversed(events) if e.get('sender')==sender and e.get('username')==u['username'] and e['status']=='pending' and e.get('candidates')),None)
            if not pending:return {'reply':'Không có báo cáo chờ chọn. Gửi lại @AI cùng nội dung và tên công trình.','status':'no_context'}
            created=datetime.datetime.fromisoformat(pending['received_at'])
            if (datetime.datetime.now(datetime.timezone.utc)-created).total_seconds()>1200:return {'reply':'Báo cáo chờ chọn đã quá 20 phút. Gửi lại nội dung.','status':'expired_context'}
            index=int(choice.group(1))-1
            if not 0<=index<len(pending['candidates']):return {'reply':'Số lựa chọn không hợp lệ.','status':'invalid_choice'}
            picked=pending['candidates'][index];pending.update(project_id=picked['project_id'],version=picked['version'])
            reply='Đã chọn '+picked['name']+', chờ chủ duyệt.'
            if cfg['auto_apply']:
                try:reply=apply(pending,picked['project_id'],u)
                except Exception:reply='Đã chọn công trình; báo cáo vẫn chờ chủ do dữ liệu thay đổi hoặc vượt quyền.'
            events.append({'id':key,'sender':sender,'username':u['username'],'text':clean,'group':payload['group'],'received_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'confirmation','status':'answered','reply':reply})
            save_events(events);return {'reply':reply,'status':'answered'}
        rows=authorized_rows(u);parsed=parse(clean,rows)
        from zalo_ai import classify
        ai=classify(clean,[p['ten_cong_trinh'] for p in rows])
        if ai and ai['intent'] in ['query','update']:
            name=norm(ai['project_name']);candidates=[p for p in rows if name and name in norm(p['ten_cong_trinh'])]
            if ai['intent']=='query':parsed={'kind':'query','candidates':candidates,'list':ai['list']}
            else:
                # Explicit field commands take precedence over model extraction.
                data={k:v for k,v in ai['data'].items() if v.strip()}
                data.update(parsed.get('data',{}));data['tien_do_bao_cao']=clean
                parsed={'kind':'update','candidates':candidates,'data':data}

        event={'id':key,'sender':sender,'username':u['username'],'text':clean,'group':payload['group'],'received_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':parsed['kind'],'status':'received','ai_used':bool(ai)}
        if parsed['kind']=='query':
            matches=rows if parsed.get('list') and not parsed['candidates'] else parsed['candidates']
            if not matches:reply='Chưa xác định được công trình. Dùng tên đầy đủ hoặc: @AI công trình: Tên; tình hình?'
            elif len(matches)>1 and not parsed.get('list'):reply='Tên trùng nhiều công trình. Gửi lại tên đầy đủ: '+', '.join(p['ten_cong_trinh'] for p in matches)
            elif any(norm(x) in norm(clean) for x in ['định vị','địa chỉ','vị trí']):reply='\n'.join(p['ten_cong_trinh']+': '+(p.get('dinh_vi') or 'Chưa có định vị.') for p in matches[:10])
            else:reply='\n\n'.join(p['ten_cong_trinh']+'\nXưởng: '+p['xuong']+' | Kính: '+p['kinh']+'\nVệ sinh: '+p['ve_sinh']+' | Chìa khóa: '+p['giao_chia_khoa']+'\nLịch lắp: '+p.get('lich_lap_dat','')+' | Lấy ngày: '+p['lap_lay_ngay']+'\nThành viên: '+p.get('thanh_vien','')+'\nThiếu: '+p.get('thieu_hang_muc','')+'\nTrạng thái: '+p['trang_thai']+'\nBáo cáo: '+p['tien_do_bao_cao'][-1200:] for p in matches[:10])
            event['status']='answered';event['reply']=reply;events.append(event);save_events(events);return {'reply':reply,'status':'answered'}
        event['data']=parsed['data'];matches=parsed['candidates'];event['candidates']=[{'project_id':p['row_index'],'name':p['ten_cong_trinh'],'version':p['version']} for p in matches]
        if len(matches)==1:event.update(project_id=matches[0]['row_index'],version=matches[0]['version'])
        event['status']='pending';reply='Đã nhận báo cáo, chờ chủ duyệt trên web.'
        if len(matches)!=1:
            reply='Chưa rõ công trình; báo cáo chờ chủ chọn trên web. Lần sau dùng: @AI công trình: Tên đầy đủ; nội dung.'
            if matches:reply+='\n'+ '\n'.join(str(i)+'. '+p['ten_cong_trinh'] for i,p in enumerate(matches,1))+'\nTrả lời @AI chọn 1 (hoặc số tương ứng).'
        elif cfg['auto_apply']:
            try:reply=apply(event,matches[0]['row_index'],u)
            except Exception:reply='Báo cáo chờ chủ duyệt do quyền cập nhật hoặc dữ liệu đã thay đổi.'
        event['reply']=reply;events.append(event);save_events(events);return {'reply':reply,'status':event['status']}


def receive_location(payload):
    from main import users
    from location_scanner import normalize_map_url
    cfg=settings()
    if not cfg['enabled'] or not cfg['location_enabled'] or payload.get('group')!=cfg['location_group_name']:return {'status':'ignored'}
    sender=str(payload.get('sender','')).strip();u=users().get(cfg['senders'].get(sender,''))
    if not u:return {'status':'unmapped_sender'}
    label=str(payload.get('label','')).strip();link=normalize_map_url(str(payload.get('url','')))
    if not label or len(label)>300 or not link:raise ValueError('Định vị hoặc tên công trình không hợp lệ.')
    mid=str(payload.get('message_id',''))
    if not mid or len(mid)>300:raise ValueError('Thiếu mã tin định vị.')
    with LOCK:
        events=queue();key=hashlib.sha256((payload['group']+'|location|'+mid).encode()).hexdigest()
        if any(e['id']==key for e in events):return {'status':'duplicate'}
        rows=authorized_rows(u);matches=[p for p in rows if norm(label) in norm(p['ten_cong_trinh'])]
        event={'id':key,'sender':sender,'username':u['username'],'text':'Định vị '+label+': '+link,'group':payload['group'],'received_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'location','status':'pending','data':{'dinh_vi':link,'tien_do_bao_cao':'Định vị '+label+': '+link},'candidates':[{'project_id':p['row_index'],'name':p['ten_cong_trinh'],'version':p['version']} for p in matches]}
        if len(matches)==1:
            event.update(project_id=matches[0]['row_index'],version=matches[0]['version'])
            if cfg['auto_apply']:
                try:apply(event,matches[0]['row_index'],u)
                except Exception:pass
        events.append(event);save_events(events);return {'status':event['status']}
