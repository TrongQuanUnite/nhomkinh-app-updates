"""Field permissions shared by web and the optional bridge."""
from store import FIELDS
EDITABLE_FIELDS=set(FIELDS)-{'hinh_anh','thoi_gian'}
PERMISSION_FIELDS=EDITABLE_FIELDS|{'hinh_anh'}
def editable_fields(user):
    if user.get('role')=='chu':return EDITABLE_FIELDS.copy()
    granted=user.get('permissions',[])
    if not isinstance(granted,list):return set()
    return set(k for k in granted if isinstance(k,str)) & EDITABLE_FIELDS

def can_upload(user):
    return user.get('role')=='chu' or 'hinh_anh' in (user.get('permissions') or [])
