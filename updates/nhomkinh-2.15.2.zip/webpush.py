"""Web Push (RFC 8030 / RFC 8291 aes128gcm / RFC 8292 VAPID) & 24h schedule reminder worker."""
import base64, datetime, hashlib, hmac, json, math, re, secrets, struct, threading, time
from urllib.parse import urlparse
import jwt, requests
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from store import BASE, LOCK, store, save_json
from workflow import overall_status

TZ = datetime.timezone(datetime.timedelta(hours=7))
VAPID_FILE = BASE / 'vapid_keys.json'
SUBS_FILE = BASE / 'push_subscriptions.json'
SENT_FILE = BASE / 'push_reminders_sent.json'
VAPID_SUBJECT = 'mailto:kaelquan.liar@gmail.com'

_cache_lock = threading.Lock()
_cached_rows = None
_cached_at = 0.0
_worker_started = False


def b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode('ascii')


def b64url_decode(text: str) -> bytes:
    cleaned = re.sub(r'\s+', '', str(text or ''))
    pad = '=' * ((4 - len(cleaned) % 4) % 4)
    return base64.urlsafe_b64decode(cleaned + pad)


def vapid_keys() -> dict:
    with LOCK:
        if VAPID_FILE.exists():
            try:
                data = json.loads(VAPID_FILE.read_text('utf8'))
                if data.get('private_pem') and data.get('public_key'):
                    return data
            except Exception:
                pass
        priv = ec.generate_private_key(ec.SECP256R1())
        priv_pem = priv.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        ).decode('ascii')
        pub_bytes = priv.public_key().public_bytes(
            encoding=serialization.Encoding.X962,
            format=serialization.PublicFormat.UncompressedPoint,
        )
        data = {'private_pem': priv_pem, 'public_key': b64url_encode(pub_bytes)}
        save_json(VAPID_FILE, data)
        return data


def public_key() -> str:
    return vapid_keys()['public_key']


def subscriptions() -> list[dict]:
    with LOCK:
        if not SUBS_FILE.exists():
            return []
        try:
            data = json.loads(SUBS_FILE.read_text('utf8'))
            return data if isinstance(data, list) else []
        except Exception:
            return []


def validate_subscription(sub: dict) -> dict:
    if not isinstance(sub, dict):
        raise ValueError('Dữ liệu đăng ký thông báo không hợp lệ.')
    endpoint = str(sub.get('endpoint') or '').strip()
    parsed = urlparse(endpoint)
    if parsed.scheme != 'https' or not parsed.hostname or len(endpoint) > 2048:
        raise ValueError('Endpoint thông báo phải dùng HTTPS hợp lệ.')
    host = parsed.hostname.lower()
    if host in {'localhost', '127.0.0.1', '::1'} or host.startswith(('10.', '192.168.', '169.254.')):
        raise ValueError('Endpoint thông báo không hợp lệ.')
    keys = sub.get('keys')
    if not isinstance(keys, dict):
        raise ValueError('Thiếu khóa mã hóa thông báo (p256dh/auth).')
    try:
        p256dh_raw = b64url_decode(keys.get('p256dh', ''))
        auth_raw = b64url_decode(keys.get('auth', ''))
        if len(p256dh_raw) != 65 or p256dh_raw[0] != 0x04:
            raise ValueError()
        ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), p256dh_raw)
        if len(auth_raw) < 16:
            raise ValueError()
    except Exception:
        raise ValueError('Khóa mã hóa thông báo đẩy không hợp lệ.')
    return {
        'endpoint': endpoint,
        'keys': {
            'p256dh': b64url_encode(p256dh_raw),
            'auth': b64url_encode(auth_raw),
        },
    }


def subscribe(user: dict, sub: dict, user_agent: str = '') -> dict:
    clean = validate_subscription(sub)
    now_str = datetime.datetime.now(TZ).isoformat(timespec='seconds')
    entry = {
        'endpoint': clean['endpoint'],
        'keys': clean['keys'],
        'username': user.get('username', ''),
        'full_name': user.get('full_name', ''),
        'user_agent': str(user_agent or '')[:200],
        'updated_at': now_str,
    }
    with LOCK:
        subs = [s for s in subscriptions() if s.get('endpoint') != clean['endpoint']]
        subs.append(entry)
        save_json(SUBS_FILE, subs[-200:])
    return entry


def unsubscribe(endpoint: str) -> bool:
    endpoint = str(endpoint or '').strip()
    if not endpoint:
        return False
    with LOCK:
        subs = subscriptions()
        filtered = [s for s in subs if s.get('endpoint') != endpoint]
        if len(filtered) != len(subs):
            save_json(SUBS_FILE, filtered)
            return True
    return False


def _hkdf_extract(salt: bytes, ikm: bytes) -> bytes:
    return hmac.new(salt, ikm, hashlib.sha256).digest()


def _hkdf_expand(prk: bytes, info: bytes, length: int) -> bytes:
    out = b''
    prev = b''
    counter = 1
    while len(out) < length:
        prev = hmac.new(prk, prev + info + bytes([counter]), hashlib.sha256).digest()
        out += prev
        counter += 1
    return out[:length]


def encrypt_rfc8291(p256dh_b64: str, auth_b64: str, plaintext: bytes, salt: bytes = None, as_private=None) -> bytes:
    """Encrypt Web Push payload using RFC 8291 (aes128gcm content encoding)."""
    ua_public_bytes = b64url_decode(p256dh_b64)
    auth_secret = b64url_decode(auth_b64)
    ua_public_key = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), ua_public_bytes)

    salt = salt or secrets.token_bytes(16)
    as_private = as_private or ec.generate_private_key(ec.SECP256R1())
    as_public_bytes = as_private.public_key().public_bytes(
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.UncompressedPoint,
    )

    shared_secret = as_private.exchange(ec.ECDH(), ua_public_key)
    prk_key = _hkdf_extract(auth_secret, shared_secret)
    key_info = b'WebPush: info\x00' + ua_public_bytes + as_public_bytes
    ikm = _hkdf_expand(prk_key, key_info, 32)

    prk = _hkdf_extract(salt, ikm)
    cek = _hkdf_expand(prk, b'Content-Encoding: aes128gcm\x00', 16)
    nonce = _hkdf_expand(prk, b'Content-Encoding: nonce\x00', 12)

    record = plaintext + b'\x02'
    ciphertext = AESGCM(cek).encrypt(nonce, record, None)
    header = salt + struct.pack('>I', 4096) + struct.pack('B', len(as_public_bytes)) + as_public_bytes
    return header + ciphertext


def vapid_headers(endpoint: str) -> dict:
    keys = vapid_keys()
    parsed = urlparse(endpoint)
    aud = f'{parsed.scheme}://{parsed.netloc}'
    claims = {
        'aud': aud,
        'exp': int(time.time()) + 12 * 3600,
        'sub': VAPID_SUBJECT,
    }
    token = jwt.encode(claims, keys['private_pem'], algorithm='ES256')
    if isinstance(token, bytes):
        token = token.decode('ascii')
    return {
        'Authorization': f"vapid t={token}, k={keys['public_key']}",
        'Content-Encoding': 'aes128gcm',
        'Content-Type': 'application/octet-stream',
        'TTL': '86400',
        'Urgency': 'high',
    }


def send_push(sub: dict, payload: dict) -> tuple[bool, int]:
    body = encrypt_rfc8291(
        sub['keys']['p256dh'],
        sub['keys']['auth'],
        json.dumps(payload, ensure_ascii=False).encode('utf8'),
    )
    headers = vapid_headers(sub['endpoint'])
    r = requests.post(sub['endpoint'], data=body, headers=headers, timeout=15)
    if r.status_code in {404, 410}:
        unsubscribe(sub['endpoint'])
        return False, r.status_code
    return (200 <= r.status_code < 300), r.status_code


def parse_schedule(value: str):
    m = re.match(r'^(\d{1,2})/(\d{1,2})/(\d{4})\s+(\d{1,2}):(\d{2})$', str(value or '').strip())
    if not m:
        return None
    d, mo, y, h, mi = map(int, m.groups())
    try:
        return datetime.datetime(y, mo, d, h, mi, tzinfo=TZ)
    except ValueError:
        return None


def sent_keys() -> list[str]:
    with LOCK:
        if not SENT_FILE.exists():
            return []
        try:
            data = json.loads(SENT_FILE.read_text('utf8'))
            return data if isinstance(data, list) else []
        except Exception:
            return []


def mark_sent(keys_to_add: list[str]):
    if not keys_to_add:
        return
    with LOCK:
        data = sent_keys()
        existing = set(data)
        for k in keys_to_add:
            if k not in existing:
                data.append(k)
                existing.add(k)
        save_json(SENT_FILE, data[-5000:])


def reminder_key(p: dict, dt: datetime.datetime) -> str:
    uid = str(p.get('cong_trinh_id') or '').strip() or f"row:{p.get('row_index')}:{p.get('ten_cong_trinh','')}"
    raw = f"{uid}|lap_lay_ngay|{dt.strftime('%Y-%m-%d %H:%M')}"
    return hashlib.sha256(raw.encode('utf8')).hexdigest()


def due_projects(rows: list[dict], now: datetime.datetime = None) -> list[dict]:
    now = now or datetime.datetime.now(TZ)
    already_sent = set(sent_keys())
    due = []
    for p in rows:
        if overall_status(p.get('trang_thai', '')) == 'Hoàn Thành':
            continue
        dt = parse_schedule(p.get('lap_lay_ngay', ''))
        if not dt:
            continue
        diff_seconds = (dt - now).total_seconds()
        if 0 < diff_seconds <= 24 * 3600:
            key = reminder_key(p, dt)
            hours_left = max(1, math.ceil(diff_seconds / 3600))
            due.append({
                'key': key,
                'project': p,
                'dt': dt,
                'hours_left': hours_left,
                'already_sent': key in already_sent,
            })
    due.sort(key=lambda x: x['dt'])
    return due


def active_subscriptions() -> list[dict]:
    subs = subscriptions()
    if not subs:
        return []
    users_file = BASE / 'users.json'
    if not users_file.exists():
        return subs
    try:
        db = json.loads(users_file.read_text('utf8'))
    except Exception:
        return subs
    return [
        s for s in subs
        if s.get('username') in db and db[s['username']].get('status', 'active') == 'active'
    ]


def check_and_send_reminders(rows: list[dict] = None, now: datetime.datetime = None) -> int:
    subs = active_subscriptions()
    if not subs:
        return 0
    if rows is None:
        with LOCK:
            rows = store.rows()
        update_cache(rows)
    items = [item for item in due_projects(rows, now=now) if not item['already_sent']]
    if not items:
        return 0
    newly_sent = []
    sent_count = 0
    for item in items:
        p = item['project']
        thau = f" · Thầu: {p['thau']}" if str(p.get('thau') or '').strip() else ''
        payload = {
            'title': f"🔔 Nhắc lịch lắp: {p.get('ten_cong_trinh', 'Công trình')}",
            'body': f"Lịch lắp lấy ngày: {p.get('lap_lay_ngay', '')} (còn khoảng {item['hours_left']} giờ){thau}",
            'tag': f"lap-lay-ngay-{item['key'][:16]}",
            'url': f"/?project={p.get('row_index', '')}",
            'row_index': p.get('row_index'),
        }
        delivered = False
        for sub in list(subs):
            try:
                ok, _ = send_push(sub, payload)
                if ok:
                    delivered = True
            except Exception:
                continue
        if delivered:
            newly_sent.append(item['key'])
            sent_count += 1
    if newly_sent:
        mark_sent(newly_sent)
    return sent_count


def update_cache(rows: list[dict]):
    global _cached_rows, _cached_at
    with _cache_lock:
        _cached_rows = [dict(r) for r in rows]
        _cached_at = time.time()


def invalidate_cache():
    global _cached_rows, _cached_at
    with _cache_lock:
        _cached_rows = None
        _cached_at = 0.0


def trigger_check_async(rows: list[dict] = None):
    if rows is not None:
        update_cache(rows)
    if not active_subscriptions():
        return
    def _run():
        try:
            with _cache_lock:
                snapshot = list(_cached_rows) if _cached_rows is not None else None
            check_and_send_reminders(rows=snapshot)
        except Exception:
            pass
    threading.Thread(target=_run, daemon=True).start()


def _worker_loop():
    while True:
        try:
            if active_subscriptions():
                with _cache_lock:
                    snapshot = list(_cached_rows) if _cached_rows is not None else None
                    age = time.time() - _cached_at
                if snapshot is None or age >= 900:
                    with LOCK:
                        snapshot = store.rows()
                    update_cache(snapshot)
                check_and_send_reminders(rows=snapshot)
        except Exception:
            pass
        time.sleep(30)


def start_worker():
    global _worker_started
    with _cache_lock:
        if _worker_started:
            return
        _worker_started = True
    threading.Thread(target=_worker_loop, daemon=True, name='webpush-reminder-worker').start()
