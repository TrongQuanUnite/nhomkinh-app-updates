from urllib.parse import urlparse
def normalize_link(value):
    value=str(value or '').strip()
    if not value:return ''
    parsed=urlparse(value)
    if parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password or len(value)>3000 or any(ord(c)<32 for c in value):
        raise ValueError('Link bản vẽ cần là đường dẫn HTTPS hợp lệ.')
    return value

def drive_file_id(value):
    import re
    from urllib.parse import parse_qs
    parsed=urlparse(value)
    if parsed.hostname!='drive.google.com':return ''
    match=re.search(r'^/file/d/([A-Za-z0-9_-]+)(?:/|$)',parsed.path)
    if match:return match.group(1)
    raw=parse_qs(parsed.query).get('id',[''])[0]
    return raw if re.fullmatch('[A-Za-z0-9_-]+',raw) else ''


def legacy_files(project):
    import json
    raw=project.get('tep_luu_tru') or '[]'
    try:
        files=json.loads(raw)
        if not isinstance(files,list) or any(not isinstance(f,dict) or not all(isinstance(f.get(k),str) for k in ('id','url','name','author','time')) or not drive_file_id(f['url']) for f in files):raise ValueError()
        return files
    except (ValueError,TypeError):raise ValueError('Danh sách file lưu trữ không hợp lệ. Liên hệ chủ để kiểm tra dữ liệu.')


def stored_files(project):
    import json
    from store import BASE
    path=BASE/'project_files.json'
    db=json.loads(path.read_text('utf8')) if path.exists() else {}
    uid=project.get('cong_trinh_id','')
    return db[uid] if uid and uid in db else legacy_files(project)

def save_files(uid,entries):
    import json
    from store import BASE,save_json
    path=BASE/'project_files.json'
    db=json.loads(path.read_text('utf8')) if path.exists() else {}
    db[uid]=entries
    save_json(path,db)
